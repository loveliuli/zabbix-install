#!/bin/bash
#author qunxue
#version 0.1
#update logs:
#1.add argv for scripts at 2015/07/02

ipaddr_bjly=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "10.254"|wc -l`
ipaddr_bjly_proxy='10.254.9.178'
function install_agent()
{
  wget http://42.62.120.210:10086/bjly/zabbix-2.2.4-base.sh
  /bin/bash zabbix-2.2.4-base.sh uninstall $1
  /bin/bash zabbix-2.2.4-base.sh install_proxy_agent  $1
  rm -rf zabbix-2.2.4-base.sh
}

if [ ${ipaddr_bjly} -ge 1 ];then

     install_agent ${ipaddr_bjly_proxy}

fi
