#!/bin/sh
#. /home/oracle/.bash_profile
for SID in $(ps -fu oracle | grep pmon | grep -v grep | cut -d_ -f3- | sort); do
export ORACLE_SID=$SID
arc_gap=`sqlplus -silent '/ as sysdba' << EOSQL
whenever sqlerror exit sql.sqlcode
set pagesize 0 feedback off verify off heading off echo off
select count(*) from v\\$archive_gap;
exit;
EOSQL`

#echo "$arc_gap"
if [ $arc_gap -gt 0 ];
then
gap_min=`sqlplus -silent '/ as sysdba' << EOSQL
whenever sqlerror exit sql.sqlcode
set pagesize 0 feedback off verify off heading off echo off
select trunc(1440*(sysdate-controlfile_time)/60) FROM v\\$database;
exit;
EOSQL`
echo "$SID gap $gap_min"
else
echo "$SID sync Ok"
fi
done
