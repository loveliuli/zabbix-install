#!/bin/expect
set timeout -1
spawn fdisk /dev/vdb
expect "Command (m for help):"
send "n\n"
expect "Command action"
send "p\n"
expect "Partition number (1-4):"
send "\n"
expect "First cylinder (1-416101, default 1):"
send "\n"
expect "Last cylinder, +cylinders or +size{K,M,G} (1-416101, default 416101):"
send "\n"
expect "Command (m for help):"
send "w\n"
expect eof
