#!/bin/bash
expect execFdisk.sh
mkfs.ext4 /dev/vdb
mkdir /data
echo /dev/vdb /data ext4 defaults 0 0 >> /etc/fstab
mount -a
df
