#!/bin/bash
#author qunxue
#version 0.1
#update logs:
#1.add argv for scripts at 2015/07/02

ipaddr_bjlg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "42.62.96|42.62.102|115.182.195|120.132.72.|123.59.13.|10.136.62|10.136.63|114.112.71.235"|wc -l`
ipaddr_bjlg_proxy='42.62.96.96'

ipaddr_bjzw=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "42.62.70|42.62.15"|wc -l`
ipaddr_bjzw_proxy='42.62.15.221'

ipaddr_gzqxg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "121.14.|101.251.|10.140|113.106.|10.251|10.104|10.249"|wc -l`
ipaddr_gzqxg_proxy='121.14.30.85'

ipaddr_tjyxb=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "125.39.38.|125.39.61.|125.39.136"|wc -l`
ipaddr_bjlg_proxy='42.62.96.96'

ipaddr_bjyz=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "10.254|10.136.|10.137|10.132"|wc -l`
ipaddr_bjyz_proxy='120.132.90.31'

ipaddr_hk=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "172.30|61.8.|172.31.11.|172.31.12.|172.31.18.65"|wc -l`
ipaddr_hk_proxy='172.16.1.12'

ipaddr_usa=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "5.1.|172.31.51.|172.31.52|172.31.61"|wc -l`
ipaddr_usa_proxy='52.1.88.210'

ipaddr_lq=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "183.56.170."|wc -l`
ipaddr_gzqxg_proxy='121.14.30.85'

ipaddr_dx=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "172.24.150."|wc -l`
#ipaddr_bjdx_proxy='120.92.14.34'
ipaddr_bjdx_proxy='172.24.150.34'
function install_agent()
{

  wget http://42.62.120.210:10086/base/zabbix-2.2.4-base.sh
  /bin/bash zabbix-2.2.4-base.sh uninstall $1
  /bin/bash zabbix-2.2.4-base.sh install_proxy_agent  $1
  rm -rf zabbix-2.2.4-base.sh
}

if [ ${ipaddr_bjlg} -ge 1 ];then

     install_agent ${ipaddr_bjlg_proxy}

elif [ ${ipaddr_bjzw} -ge 1 ];then
  
     install_agent ${ipaddr_bjzw_proxy}  

elif [ ${ipaddr_gzqxg} -ge 1 ];then
    
     install_agent ${ipaddr_gzqxg_proxy}

elif [ ${ipaddr_hk} -ge 1 ];then
   
     install_agent ${ipaddr_hk_proxy}

elif [ ${ipaddr_usa} -ge 1 ];then
    
     install_agent ${ipaddr_usa_proxy}

elif [ ${ipaddr_tjyxb} -ge 1 ];then
    
     install_agent ${ipaddr_bjlg_proxy}

elif [ ${ipaddr_bjyz} -ge 1 ];then
   
     install_agent ${ipaddr_bjyz_proxy}

elif [ ${ipaddr_lq} -ge 1 ];then
    
     install_agent ${ipaddr_gzqxg_proxy}
elif [ ${ipaddr_dx} -ge 1  ];then 
    install_agent ${ipaddr_bjdx_proxy}
fi
