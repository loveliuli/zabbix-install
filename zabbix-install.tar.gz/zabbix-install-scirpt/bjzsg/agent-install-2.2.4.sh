#!/bin/bash


#pubip=`curl -s http://ipinfo.io|grep ip|awk -F[\"] '{print $4}'`
pubip=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"`

ipaddr_gzqxg=`echo $pubip|grep -E "121.14.|101.251.106.|172.31.0."|wc -l`
ipaddr_gzqxg_jx3_proxy='172.31.0.6'

ipaddr_tjyxb=`echo $pubip|grep -E "125.39.38\.|125.39.61\.|125.39.136.|125.39.62."|wc -l`
ipaddr_tjyxb_proxy='172.31.0.6'


ipaddr_shksyun=`echo $pubip|grep -E "120.92.|180.235."|wc -l`

#ipaddr_shksyun_proxy='120.92.230.105'
ipaddr_shksyun_proxy='172.31.0.6'

#ipaddr_shwgq=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "180.235."|wc -l`
ipaddr_shwgq=`echo $pubip|grep -E "180.235."|wc -l`
ipaddr_shwgq_proxy='172.31.0.6'

function install_agent() {

  wget http://42.62.120.210:10086/bjzsg/zabbix-2.2.4-base.sh
  /bin/bash zabbix-2.2.4-base.sh uninstall $1 
  /bin/bash zabbix-2.2.4-base.sh install_proxy_agent  $1
  rm -rf zabbix-2.2.4-base.sh


}

if [ ${ipaddr_gzqxg} -ge 1 ];then

    install_agent ${ipaddr_gzqxg_jx3_proxy}

elif [ ${ipaddr_shksyun} -ge 1 ];then

     install_agent ${ipaddr_shksyun_proxy}

elif [ ${ipaddr_shwgq} -ge 1 ];then

     install_agent ${ipaddr_shwgq_proxy}

else
   
    install_agent ${ipaddr_tjyxb_proxy}

fi
