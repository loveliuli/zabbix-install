#!/usr/bin/env python
import os
import json
import urllib2
import sys

serverid_list = ['dbflushd','dbproxyd/','/home/logbak/log/dbproxyd1/','/home/logbak/log/dbproxyd2/','/home/logbak/log/relayd/','/home/logbak/log/gamepvp/','/home/logbak/log/gamepvp1/','/home/logbak/log/gamepvp2/','/home/logbak/log/gamepvp3/','/home/logbak/log/gamegs/','/home/logbak/log/gamegs1/','/home/logbak/log/gamegs2/','/home/logbak/log/mgrpvpd/','/home/logbak/log/mgrpvpd/','/home/logbak/log/logind/','go-jxhttp-master','redis-server']

ports = []
for port in  serverid_list:
    #r = os.path.basename(port.strip())
    ports += [{'{#SERVERID}':port}]
print json.dumps({'data':ports},sort_keys=True,indent=4,separators=(',',':'))
