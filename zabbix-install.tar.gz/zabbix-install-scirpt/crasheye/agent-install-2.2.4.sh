#!/bin/bash
#author qunxue
#version 0.1
#update logs:
#1.add argv for scripts at 2015/07/02

ipaddr_bjlg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "42.62.96|42.62.102|115.182.195|120.132.72.|123.59.13.|10.136.62|10.136.63"|wc -l`
ipaddr_bjlg_proxy='172.16.8.21'

ipaddr_bjzw=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "42.62.70|42.62.15"|wc -l`
ipaddr_bjzw_proxy='172.16.8.21'

ipaddr_gzqxg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "121.14.|101.251.|10.140|113.106.|10.251|10.104|10.249"|wc -l`
ipaddr_gzqxg_proxy='172.16.8.21'

ipaddr_tjyxb=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "125.39.38.|125.39.61.|125.39.136"|wc -l`
ipaddr_bjlg_proxy='172.16.8.21'

ipaddr_bjyz=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "10.254|10.136|10.137"|wc -l`
ipaddr_bjyz_proxy='172.16.8.21'

ipaddr_hk=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "205.252|61.8.|172.31.11.|172.31.12.|172.31.18.65"|wc -l`
ipaddr_hk_proxy='172.16.8.21'

ipaddr_usa=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "52.|172.31.51."|wc -l`
ipaddr_usa_proxy='172.16.8.21'

ipaddr_lq=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "183.56.170.|172.16.8"|wc -l`
ipaddr_gzqxg_proxy='172.16.8.21'


function install_agent()
{

  wget http://42.62.120.210:10086/crasheye/zabbix-2.2.4-base.sh
  /bin/bash zabbix-2.2.4-base.sh uninstall $1
  /bin/bash zabbix-2.2.4-base.sh install_proxy_agent  $1
  rm -rf zabbix-2.2.4-base.sh
}

if [ ${ipaddr_bjlg} -ge 1 ];then

     install_agent ${ipaddr_bjlg_proxy}

elif [ ${ipaddr_bjzw} -ge 1 ];then
  
     install_agent ${ipaddr_bjzw_proxy}  

elif [ ${ipaddr_gzqxg} -ge 1 ];then
    
     install_agent ${ipaddr_gzqxg_proxy}

elif [ ${ipaddr_hk} -ge 1 ];then
   
     install_agent ${ipaddr_hk_proxy}

elif [ ${ipaddr_usa} -ge 1 ];then
    
     install_agent ${ipaddr_usa_proxy}

elif [ ${ipaddr_tjyxb} -ge 1 ];then
    
     install_agent ${ipaddr_bjlg_proxy}

elif [ ${ipaddr_bjyz} -ge 1 ];then
   
     install_agent ${ipaddr_bjyz_proxy}

elif [ ${ipaddr_lq} -ge 1 ];then
    
     install_agent ${ipaddr_gzqxg_proxy}
fi
