#!/bin/bash

ipaddr_bjlg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "42.62.96|42.62.102|115.182.195|120.132.72."|wc -l`
ipaddr_bjlg_proxy='42.62.96.96'

ipaddr_bjzw=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "42.62.70|42.62.15"|wc -l`
ipaddr_bjzw_proxy='42.62.15.221'

ipaddr_gzqxg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "121.14.|101.251.106.|113.106."|wc -l`
ipaddr_gzqxg_proxy='121.14.30.85'



function install_agent() {

  wget http://42.62.120.210:10086/jx1/zabbix-2.2.4-jx1.sh
  /bin/bash zabbix-2.2.4-jx1.sh uninstall $1 
  /bin/bash zabbix-2.2.4-jx1.sh install_proxy_agent  $1
  rm -rf zabbix-2.2.4-jx1.sh

}

if [ ${ipaddr_bjlg} -ge 1 ];then
  
    install_agent  ${ipaddr_bjlg_proxy}

elif [ ${ipaddr_bjzw} -ge 1 ];then
 
    install_agent ${ipaddr_bjzw_proxy}

elif [ ${ipaddr_gzqxg} -ge 1 ];then
    
    install_agent ${ipaddr_gzqxg_proxy}

fi
