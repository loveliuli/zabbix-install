#!/bin/bash
#author qunxue
#version 0.1
#update logs:
#1.add install/uninstall function at 2015/3/27
#2.change zabbix_agent_ip get method(CentOS7's ifconfig cmd is not worked! at 2015/3/30
#3.add install for CentOS7 Version at 2015/3/30

###set variables
zabbix_agent_hostname=$(hostname)
zabbix_server_port='10051'
zabbix_server_ip='42.62.96.116'
zabbix_proxy_server_ip=$2
#zabbix_agent_ip=$(/sbin/ifconfig|grep 'inet addr:'|grep -Ev '127.0.0.1' | cut -d: -f2 | awk '{if ($1~/^10.*/) {print $1} else {print $1}}'|head -n 1)
zabbix_agent_ip=$(/sbin/ip addr|grep -w "inet"|grep -v 127.0.0.1|awk -F/ '{print $1}'|awk '{print $2}'|head -n 1)
zabbix_proxy_agent_ip=$(/sbin/ip addr|grep -w "inet"|grep -v 127.0.0.1|awk -F/ '{print $1}'|awk '{print $2}'|grep -E "172"|tail -n 1)
#zabbix_agent_header=$(/sbin/ifconfig|grep 'inet addr:'|grep -Ev '127.0.0.1' | cut -d: -f2 | awk '{if ($1~/^10.*/) {print $1} else {print $1}}'|head -n 1|cut -d . -f1)
zabbix_agent_header=$(/sbin/ip addr|grep -w "inet"|grep -v 127.0.0.1|awk -F/ '{print $1}'|awk '{print $2}'|head -n 1)


#############Check OS version##################
function modify_dash() {
if [[ $(uname -a|grep -E "el6|el5|el7|debian"|wc -l) = 1 ]];then
     echo "OK."
   else
     echo "Ubuntu system must modify dash!"
     ln -s /bin/bash /bin/sh 2>/dev/null
     echo "link created success!"
fi
}
#############Check if user is root######################
function install_zabbix_agent() {
if [ $(id -u) != "0" ]; then
    echo -e "\033[1;31m Error: You must be root to run this script!\033[0m"
    exit 1
fi

###############check network#####################
ping -c 2 www.baidu.com >>/dev/null 2>&1
if [ $? -ne 0 ];then
    echo -e "\033[1;31m Error: The host can't connect to Inetnet!\033[0m"
    exit 1
fi
################set up zabbix##############

system_version=$(uname -m)

if [[ $(grep -i -E -c "Red|CentOS" /etc/issue) = 1 ]] && [[ $(grep -i -c "release 6" /etc/issue) = 1 ]];then
   if [ $system_version == 'x86_64' ];then
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el6.x86_64.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el6.x86_64.rpm
      chkconfig zabbix-agent on
   else
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el6.i386.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el6.i386.rpm
      chkconfig zabbix-agent on
   fi
    
elif [[ $(grep -i -E -c "Red|CentOS" /etc/issue) = 1 ]] && [[ $(grep -i -c "release 5" /etc/issue) = 1 ]];then
    if [ $system_version == 'x86_64' ];then
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el5.x86_64.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el5.x86_64.rpm
      chkconfig zabbix-agent on
    else
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el5.i386.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el5.i386.rpm
      chkconfig zabbix-agent on
    fi
elif [[ $(grep -i -E -c "Red|CentOS"  /etc/redhat-release) = 1 ]] && [[ $(grep -i -c "release 7" /etc/redhat-release) = 1 ]];then
    if [ $system_version == 'x86_64' ];then
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.7-2.el7.x86_64.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.7-2.el7.x86_64.rpm
      chkconfig zabbix-agent on
    else
      echo "CentOS7 32bit!Please intall from source packages!"
    fi	
elif [[ $(grep -i -c "ubuntu" /etc/issue) = 1 ]];then
     if [ $(grep -i -c "ubuntu 12" /etc/issue) == 1 ];then
       wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+precise_all.deb
       dpkg -i zabbix-release_2.2-1+precise_all.deb
       #apt-get update
       apt-get install zabbix-agent
     else
       wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+trusty_all.deb
       dpkg -i zabbix-release_2.2-1+trusty_all.deb
       #apt-get update
       apt-get install zabbix-agent
     fi
else
      if [ $(grep -i -c "Debian GNU/Linux 6" /etc/issue) == 1 ];then
        wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+squeeze_all.deb
        dpkg -i zabbix-release_2.2-1+squeeze_all.deb
        #apt-get update
        apt-get install zabbix-agent
      else
        wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+wheezy_all.deb
        dpkg -i zabbix-release_2.2-1+wheezy_all.deb
        #apt-get update
        apt-get install zabbix-agent
      fi
fi

################mondiy zabbix agent conf###################
sed -i 's/LogFileSize=0/LogFileSize=1/g' /etc/zabbix/zabbix_agentd.conf
sed -i 's/Server=127.0.0.1/Server='$zabbix_server_ip'/g' /etc/zabbix/zabbix_agentd.conf
sed -i 's/ServerActive=127.0.0.1/ServerActive='${zabbix_server_ip}:10051'/g' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# Timeout=3/a Timeout=30' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# UnsafeUserParameters=0/a UnsafeUserParameters=1' /etc/zabbix/zabbix_agentd.conf
sed -i 's#Hostname=Zabbix server#Hostname='$zabbix_agent_hostname'#' /etc/zabbix/zabbix_agentd.conf
#sed -i 's@# SourceIP=@SourceIP='$zabbix_agent_ip'@' /etc/zabbix/zabbix_agentd.conf

mkdir -p /etc/zabbix/externalscripts/
cat >/etc/zabbix/externalscripts/gameprocess.sh <<EOF
#!/bin/bash
gameprocess=(\`ps xua|grep -E "gameserver*|RelayD|kg_goddessd_linux|kg_bishopd_linux"|grep -v grep|awk -F[/] '{print \$2}'|awk '{print \$1}'   2>/dev/null\`)

length1=\${#gameprocess[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length1;i++))
do
        printf '\n\t\t{'
        printf "\"{#GAMEPROCESS}\":\"\${gameprocess[\$i]}\"}"
        if [ \$i -lt \$[\$length1-1] ];then
                printf ','
        fi
done
printf  "\n\t]\n"
printf "}\n"
EOF

#################setting sudo priority######################
#sed -i 's/^Defaults.*.requiretty/#Defaults    requiretty/' /etc/sudoers
#echo "zabbix ALL=(ALL)       NOPASSWD: /etc/init.d/irqbalance start" >>/etc/sudoers
chmod +w /etc/sudoers 
sed -i 's/^\(Defaults\s\+requiretty\)/#\1/' /etc/sudoers
echo 'zabbix ALL=(ALL)       NOPASSWD: ALL' >> /etc/sudoers
chmod 440 /etc/sudoers
###############set discovery disk io########################

cat >>/etc/zabbix/zabbix_agentd.conf<<EOF
UserParameter=custom.vfs.dev.discovery,/bin/sh /etc/zabbix/externalscripts/disk.sh 
# reads completed successfully
UserParameter=custom.vfs.dev.read.ops[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$4}'
# sectors read
UserParameter=custom.vfs.dev.read.sectors[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$6}'
# time spent reading (ms)
UserParameter=custom.vfs.dev.read.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$7}'
# writes completed
UserParameter=custom.vfs.dev.write.ops[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$8}'
# sectors written
UserParameter=custom.vfs.dev.write.sectors[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$10}'
# time spent writing (ms)
UserParameter=custom.vfs.dev.write.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$11}'
# I/Os currently in progress
UserParameter=custom.vfs.dev.io.active[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$12}'
# time spent doing I/Os (ms)
UserParameter=custom.vfs.dev.io.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$13}'
#people info for yycs
UserParameter=xsj.gs.people[*],netstat -ant|grep -w '\$1'|grep -w "ESTABLISHED"|wc -l
UserParameter=custom.process.discovery,/bin/sh /etc/zabbix/externalscripts/gameprocess.sh
# discovery game process
UserParameter=custom.game.process.num[*],ps xua|grep -w "\$1"|grep -v grep|wc -l
UserParameter=custom.game.process.cpu[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$3}'
UserParameter=custom.game.process.mem[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$4}'
UserParameter=custom.game.process.vsz.mem[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$5}'
UserParameter=custom.game.process.rss.mem[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$6}'
EOF

cat >/etc/zabbix/externalscripts/disk.sh <<EOF
#!/bin/bash
diskarray=(\`cat /proc/diskstats |grep -E "\bvd[abcdefg]\b|\bhd[abcdefg]\b|\bsd[abcdefg]\b|\bc0d0p[0-9]\b"|grep -i "\b\$1\b"|awk '{print \$3}'|sort|uniq   2>/dev/null\`)
length2=\${#diskarray[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length2;i++))
do
    printf '\n\t\t{'
    printf "\"{#DISK}\":\"\${diskarray[\$i]}\"}"
    if [ \$i -lt \$[\$length2-1] ];then
            printf ','
    fi
done
printf  "\n\t]\n"
printf "}\n"
EOF
chown -R zabbix:zabbix /etc/zabbix/externalscripts/gameprocess.sh
chmod 755 /etc/zabbix/externalscripts/gameprocess.sh
chown -R zabbix:zabbix /etc/zabbix/externalscripts/disk.sh
chmod 755 /etc/zabbix/externalscripts/disk.sh
iptable_num=`iptables-save |grep ${zabbix_server_ip}|wc -l`

if [ ${iptable_num} -ge 1 ];then
echo "iptables had been added!"
else
iptables -I INPUT 3 -s ${zabbix_server_ip}/32 -j ACCEPT
iptables-save >/etc/sysconfig/iptables
fi
echo "Congratulations on your successful installation!"
service zabbix-agent restart
}


function install_zabbix_proxy_agent() {
if [ $(id -u) != "0" ]; then
    echo -e "\033[1;31m Error: You must be root to run this script!\033[0m"
    exit 1
fi

###############check network#####################
ping -c 2 www.baidu.com >>/dev/null 2>&1
if [ $? -ne 0 ];then
    echo -e "\033[1;31m Error: The host can't connect to Inetnet!\033[0m"
    exit 1
fi
################set up zabbix##############

system_version=$(uname -m)

if [[ $(grep -i -E -c "Red|CentOS" /etc/issue) = 1 ]] && [[ $(grep -i -c "release 6" /etc/issue) = 1 ]];then
   if [ $system_version == 'x86_64' ];then
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el6.x86_64.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el6.x86_64.rpm
      chkconfig zabbix-agent on
   else
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el6.i386.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el6.i386.rpm
      chkconfig zabbix-agent on
   fi
    
elif [[ $(grep -i -E -c "Red|CentOS" /etc/issue) = 1 ]] && [[ $(grep -i -c "release 5" /etc/issue) = 1 ]];then
    if [ $system_version == 'x86_64' ];then
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el5.x86_64.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el5.x86_64.rpm
      chkconfig zabbix-agent on
    else
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el5.i386.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el5.i386.rpm
      chkconfig zabbix-agent on
    fi
elif [[ $(grep -i -E -c "Red|CentOS"  /etc/redhat-release) = 1 ]] && [[ $(grep -i -c "release 7" /etc/redhat-release) = 1 ]];then
    if [ $system_version == 'x86_64' ];then
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.7-2.el7.x86_64.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.7-2.el7.x86_64.rpm
      chkconfig zabbix-agent on
    else
      echo "CentOS7 32bit!Please intall from source packages!"
    fi	
elif [[ $(grep -i -c "ubuntu" /etc/issue) = 1 ]];then
     if [ $(grep -i -c "ubuntu 12" /etc/issue) == 1 ];then
       wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+precise_all.deb
       dpkg -i zabbix-release_2.2-1+precise_all.deb
       #apt-get update
       apt-get install zabbix-agent
     else
       wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+trusty_all.deb
       dpkg -i zabbix-release_2.2-1+trusty_all.deb
       #apt-get update
       apt-get install zabbix-agent
     fi
else
      if [ $(grep -i -c "Debian GNU/Linux 6" /etc/issue) == 1 ];then
        wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+squeeze_all.deb
        dpkg -i zabbix-release_2.2-1+squeeze_all.deb
        #apt-get update
        apt-get install zabbix-agent
      else
        wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+wheezy_all.deb
        dpkg -i zabbix-release_2.2-1+wheezy_all.deb
        #apt-get update
        apt-get install zabbix-agent
      fi
fi

################mondiy zabbix agent conf###################
sed -i 's/LogFileSize=0/LogFileSize=1/g' /etc/zabbix/zabbix_agentd.conf
sed -i 's/Server=127.0.0.1/Server='$zabbix_proxy_server_ip'/g' /etc/zabbix/zabbix_agentd.conf
sed -i 's/ServerActive=127.0.0.1/ServerActive='${zabbix_proxy_server_ip}:10051'/g' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# Timeout=3/a Timeout=30' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# UnsafeUserParameters=0/a UnsafeUserParameters=1' /etc/zabbix/zabbix_agentd.conf
sed -i 's#Hostname=Zabbix server#Hostname='$zabbix_agent_hostname'#' /etc/zabbix/zabbix_agentd.conf
#sed -i 's@# SourceIP=@SourceIP='$zabbix_proxy_agent_ip'@' /etc/zabbix/zabbix_agentd.conf


mkdir -p /etc/zabbix/externalscripts/
cat >/etc/zabbix/externalscripts/gameprocess.sh <<EOF
#!/bin/bash
gameprocess=(\`ps xua|grep -E "gameserver*|RelayD|kg_goddessd_linux|kg_bishopd_linux"|grep -v grep|awk -F[/] '{print \$2}'|awk '{print \$1}'   2>/dev/null\`)

length1=\${#gameprocess[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length1;i++))
do
        printf '\n\t\t{'
        printf "\"{#GAMEPROCESS}\":\"\${gameprocess[\$i]}\"}"
        if [ \$i -lt \$[\$length1-1] ];then
                printf ','
        fi
done
printf  "\n\t]\n"
printf "}\n"
EOF

#################setting sudo priority######################
#sed -i 's/^Defaults.*.requiretty/#Defaults    requiretty/' /etc/sudoers
#echo "zabbix ALL=(ALL)       NOPASSWD: /etc/init.d/irqbalance start" >>/etc/sudoers
chmod +w /etc/sudoers 
sed -i 's/^\(Defaults\s\+requiretty\)/#\1/' /etc/sudoers
echo 'zabbix ALL=(ALL)       NOPASSWD: ALL' >> /etc/sudoers
chmod 440 /etc/sudoers
###############set discovery disk io########################

cat >>/etc/zabbix/zabbix_agentd.conf<<EOF
UserParameter=custom.vfs.dev.discovery,/bin/sh /etc/zabbix/externalscripts/disk.sh 
# reads completed successfully
UserParameter=custom.vfs.dev.read.ops[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$4}'
# sectors read
UserParameter=custom.vfs.dev.read.sectors[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$6}'
# time spent reading (ms)
UserParameter=custom.vfs.dev.read.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$7}'
# writes completed
UserParameter=custom.vfs.dev.write.ops[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$8}'
# sectors written
UserParameter=custom.vfs.dev.write.sectors[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$10}'
# time spent writing (ms)
UserParameter=custom.vfs.dev.write.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$11}'
# I/Os currently in progress
UserParameter=custom.vfs.dev.io.active[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$12}'
# time spent doing I/Os (ms)
UserParameter=custom.vfs.dev.io.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$13}'
#people info for yycs
UserParameter=xsj.gs.people[*],netstat -ant|grep -w '\$1'|grep -w "ESTABLISHED"|wc -l
UserParameter=custom.process.discovery,/bin/sh /etc/zabbix/externalscripts/gameprocess.sh
# discovery game process
UserParameter=custom.game.process.num[*],ps xua|grep -w "\$1"|grep -v grep|wc -l
UserParameter=custom.game.process.cpu[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$3}'
UserParameter=custom.game.process.mem[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$4}'
UserParameter=custom.game.process.vsz.mem[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$5}'
UserParameter=custom.game.process.rss.mem[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$6}'
EOF

cat >/etc/zabbix/externalscripts/disk.sh <<EOF
#!/bin/bash
diskarray=(\`cat /proc/diskstats |grep -E "\bvd[abcdefg]\b|\bhd[abcdefg]\b|\bsd[abcdefg]\b|\bc0d0p[0-9]\b"|grep -i "\b\$1\b"|awk '{print \$3}'|sort|uniq   2>/dev/null\`)
length2=\${#diskarray[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length2;i++))
do
    printf '\n\t\t{'
    printf "\"{#DISK}\":\"\${diskarray[\$i]}\"}"
    if [ \$i -lt \$[\$length2-1] ];then
            printf ','
    fi
done
printf  "\n\t]\n"
printf "}\n"
EOF
chown -R zabbix:zabbix /etc/zabbix/externalscripts/gameprocess.sh
chmod 755 /etc/zabbix/externalscripts/gameprocess.sh
chown -R zabbix:zabbix /etc/zabbix/externalscripts/disk.sh
chmod 755 /etc/zabbix/externalscripts/disk.sh
iptable_num=`iptables-save |grep ${zabbix_proxy_server_ip}|wc -l`

if [ ${iptable_num} -ge 1 ];then
echo "iptables had been added!"
else
iptables -I INPUT 3 -s ${zabbix_proxy_server_ip}/32 -j ACCEPT
iptables-save >/etc/sysconfig/iptables
fi
echo "Congratulations on your successful installation!"
service zabbix-agent restart
}

function uninstall_zabbix_agent() {

################uninstall zabbix##############
if [ $(id -u) != "0" ]; then
    echo -e "\033[1;31m Error: You must be root to run this script!\033[0m"
    exit 1
fi
system_version=$(uname -m)

if [[ $(grep -i -E -c "Red|CentOS" /etc/redhat-release) = 1 ]];then
      rpm -e zabbix-agent
      rpm -e zabbix
else [[ $(grep -E -c "Ubuntu|Debian" /etc/issue) = 1 ]]
       dpkg -P zabbix-agent
fi
    
      echo >/etc/zabbix/externalscripts/disk.sh
	  echo >/etc/zabbix/externalscripts/gameprocess.sh
	  iptables -D INPUT -s ${zabbix_server_ip}/32 -j ACCEPT
	  iptables -D INPUT -s ${zabbix_proxy_server_ip}/32 -j ACCEPT
	  rm -rf /etc/init.d/zabbix_agent_om
}
case $1 in 
 install_agent) 
        modify_dash
        install_zabbix_agent
            ;;
 install_proxy_agent)
        modify_dash
        install_zabbix_proxy_agent
		    ;;

 uninstall) 
        uninstall_zabbix_agent
            ;;			
  *) 
        echo "                                                    "
		echo "Usage:$0(install_agent|install_proxy_agent|uninstall)" 
		echo "NAME"
		echo "          used to install zabbix agent"
		echo "DESCRIPTION"
		echo "           install_agent:install zabbix agent"
		echo "           install_proxy_agent:install zabbix proxy agent"
		echo "           uninstall:unintall agent"
        ;; 
esac 
