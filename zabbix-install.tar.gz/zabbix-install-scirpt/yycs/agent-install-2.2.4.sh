#!/bin/bash

ipaddr_bjlg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "42.62.96|42.62.102|115.182.195|120.132.72."|wc -l`


ipaddr_hk=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "205.252"|wc -l`

ipaddr_usa=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "52."|wc -l`


function install_agent() {

  wget http://42.62.120.210:10086/yycs/zabbix-2.2.4-yycs.sh
   /bin/bash zabbix-2.2.4-yycs.sh uninstall $1
   /bin/bash zabbix-2.2.4-yycs.sh install_proxy_agent  $1
   rm -rf zabbix-2.2.4-yycs.sh

}

if [ ${ipaddr_bjlg} -ge 1 ];then

    install_agent ${ipaddr_bjlg_proxy}

elif [ ${ipaddr_hk} -ge 1 ];then

    install_agent ${ipaddr_hk_proxy}

elif [ ${ipaddr_usa} -ge 1 ];then

    install_agent ${ipaddr_usa_proxy}

elif [ ${ipaddr_tjyxb} -ge 1 ];then

    install_agent ${ipaddr_bjlg_proxy}
fi
