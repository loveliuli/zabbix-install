#!/bin/bash

ipaddr_gzqxg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "121.14.|101.251.106."|wc -l`
ipaddr_gzqxg_jx3_proxy='172.16.105.103'

ipaddr_tjyxb=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "125.39.38.|125.39.61.|125.39.136|125.39.62"|wc -l`
ipaddr_bjlg_proxy='42.62.96.96'

function install_agent() {

  wget http://42.62.120.210:10086/jx3/zabbix-2.2.4-mysql-multi.sh
  /bin/bash zabbix-2.2.4-mysql-multi.sh uninstall $1 
  /bin/bash zabbix-2.2.4-mysql-multi.sh install_proxy_agent  $1
  rm -rf zabbix-2.2.4-mysql-multi.sh


}

if [ ${ipaddr_gzqxg} -ge 1 ];then

    install_agent ${ipaddr_gzqxg_jx3_proxy}

else
   
    install_agent ${ipaddr_bjlg_proxy}

fi
