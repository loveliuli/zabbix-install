#!/bin/bash


#pubip=`curl -s http://ipinfo.io|grep ip|awk -F[\"] '{print $4}'`
pubip=`curl -s http://ip.cn|awk '{print $2}'`
ipaddr_gzqxg=`echo $pubip|grep -E "121.14.|101.251.106."|wc -l`
ipaddr_gzqxg_jx3_proxy='172.16.105.103'

ipaddr_tjyxb=`echo $pubip|grep -E "125.39.38\.|125.39.61\.|125.39.136.|125.39.62."|wc -l`
ipaddr_bjlg_proxy='120.92.176.126'


ipaddr_shksyun=`echo $pubip|grep -E "120.92."|wc -l`
#ipaddr_shksyun_proxy='120.92.230.105'
ipaddr_shksyun_proxy='120.92.176.126
'
ipaddr_shwgq=`echo $pubip|grep -E "180.235."|wc -l`
ipaddr_shwgq_proxy='180.235.73.131'

function install_agent() {

  wget http://42.62.120.210:10086/jx3/zabbix-2.2.4-base-down.sh
  /bin/bash zabbix-2.2.4-base-down.sh uninstall $1 
  /bin/bash zabbix-2.2.4-base-down.sh install_proxy_agent $1
  rm -rf zabbix-2.2.4-base-down.sh


}

if [ ${ipaddr_gzqxg} -ge 1 ];then

    install_agent ${ipaddr_gzqxg_jx3_proxy} 

elif [ ${ipaddr_shksyun} -ge 1 ];then

     install_agent ${ipaddr_shksyun_proxy} 

elif [ ${ipaddr_shwgq} -ge 1 ];then
     install_agent ${ipaddr_shwgq_proxy}
else
   
    install_agent ${ipaddr_bjlg_proxy} 

fi
