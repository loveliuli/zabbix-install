#!/bin/bash
#author qunxue
#version 0.1
#update logs:
#1.add argv for scripts at 2015/07/02

ipaddr_bjlg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "42.62.96|42.62.102|115.182.195|123.59.13.|10.136.62|10.136.63|42.62.95|115.183.195.3"|wc -l`
ipaddr_bjlg_proxy='42.62.96.96'

ipaddr_bjzw=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "42.62.70|42.62.15|211.155.90.227|42.62.10.|114.112.71"|wc -l`
ipaddr_bjzw_proxy='42.62.15.221'

ipaddr_gzqxg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "121.14.|113.106.|10.251|10.104|10.249|10.143.52.197|121.14.11.|59.37."|wc -l`
ipaddr_gzqxg_proxy='121.14.30.85'

ipaddr_tjyxb=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "125.39.38.|125.39.61.|125.39.62.|125.39.136"|wc -l`
ipaddr_bjlg_proxy='42.62.96.96'

ipaddr_bjyz=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "10.254|10.136.|10.137|10.132|10.254.165"|wc -l`
ipaddr_bjyz_proxy='120.132.90.31'

ipaddr_hk=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "172.30|61.8.|172.31.11.|172.31.12.|172.31.18.65"|wc -l`
ipaddr_hk_proxy='172.16.1.12'

ipaddr_tw=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "203.66.80.|172.31.0."|wc -l`
ipaddr_tw_proxy='205.252.235.74'


ipaddr_usa=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "52.1.|172.31.51.|172.31.52|172.31.61|172.31.22.|172.31.5|172.31.8|172.31.14"|wc -l`
ipaddr_usa_proxy='52.1.88.210'

ipaddr_dx=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "172.24.150.|203.162.80.145"|wc -l`
#ipaddr_bjdx_proxy='120.92.14.34'
ipaddr_bjdx_proxy='172.24.150.34'


ipaddr_shqu=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "10.140|10.140.78|10.140.79|101.251|172.31.32"|wc -l`
ipaddr_shqu_proxy='120.92.230.105'


ipaddr_bjplatform=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "10.0."|wc -l`
ipaddr_bjplatform_proxy='10.0.255.253'

function install_agent()
{
 if [ ${ipaddr_hk} -ge 1 -o  ${ipaddr_usa} -ge 1 ];then
 
 wget http://205.252.235.74:10086/jxsjphone/zabbix-2.2.4-jxsjphone.sh
  /bin/bash zabbix-2.2.4-jxsjphone.sh uninstall $1
  /bin/bash zabbix-2.2.4-jxsjphone.sh install_proxy_agent  $1
  rm -rf zabbix-2.2.4-jxsjphone.sh
  
 else
  wget http://42.62.120.210:10086/jxsjphone/zabbix-2.2.4-jxsjphone.sh
  /bin/bash zabbix-2.2.4-jxsjphone.sh uninstall $1
  /bin/bash zabbix-2.2.4-jxsjphone.sh install_proxy_agent  $1
  rm -rf zabbix-2.2.4-jxsjphone.sh
  fi
}

if [ ${ipaddr_bjlg} -ge 1 ];then

     install_agent ${ipaddr_bjlg_proxy}

elif [ ${ipaddr_bjzw} -ge 1 ];then
  
     install_agent ${ipaddr_bjzw_proxy}  

elif [ ${ipaddr_tw} -ge 1 ];then
  
     install_agent ${ipaddr_tw_proxy} 

elif [ ${ipaddr_gzqxg} -ge 1 ];then
    
     install_agent ${ipaddr_gzqxg_proxy}

elif [ ${ipaddr_hk} -ge 1 ];then
   
     install_agent ${ipaddr_hk_proxy}

elif [ ${ipaddr_usa} -ge 1 ];then
    
     install_agent ${ipaddr_usa_proxy}

elif [ ${ipaddr_tjyxb} -ge 1 ];then
    
     install_agent ${ipaddr_bjlg_proxy}

elif [ ${ipaddr_bjyz} -ge 1 ];then
   
     install_agent ${ipaddr_bjyz_proxy}

elif [ ${ipaddr_dx} -ge 1  ];then 
    install_agent ${ipaddr_bjdx_proxy}
	
elif [ ${ipaddr_shqu} -ge 1   ];then
    install_agent ${ipaddr_shqu_proxy}

elif [ ${ipaddr_bjplatform} -ge 1   ];then
    install_agent ${ipaddr_bjplatform_proxy}
fi
