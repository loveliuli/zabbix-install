#!/bin/bash

ipaddr_shhb=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "61.152|61.129|222.73|180.235."|wc -l`
ipaddr_shhb_proxy='180.235.73.131'

ipaddr_gzqxg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "59.37"|wc -l`
ipaddr_gzqxg_proxy='121.14.30.85'

function install_agent() {

  wget http://42.62.120.210:10086/oracle/zabbix-2.2.4-oracle.sh
  /bin/bash zabbix-2.2.4-oracle.sh uninstall $1 
  /bin/bash zabbix-2.2.4-oracle.sh install_proxy_agent  $1
  rm -rf zabbix-2.2.4-oracle.sh


}

if [ ${ipaddr_shhb} -ge 1 ];then

    install_agent ${ipaddr_shhb_proxy}

else
   
    install_agent ${ipaddr_gzqxg_proxy}

fi
