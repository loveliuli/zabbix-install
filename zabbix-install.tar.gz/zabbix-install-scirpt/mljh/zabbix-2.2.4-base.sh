#!/bin/bash
#author qunxue
#version 0.1
#update logs:
#1.add install/uninstall function at 2015/3/27
#2.change zabbix_agent_ip get method(CentOS7's ifconfig cmd is not worked! at 2015/3/30
#3.add install for CentOS7 Version at 2015/3/30
#4.add web、DB for base at 2015/09/08
#5.add zabbix_agent_ip check as pubilic
#6.add login ssh monitor
#7.modify zabbix_agent_ip get method

###set variables
zabbix_agent_hostname=$(hostname)
zabbix_server_port='10051'
zabbix_server_ip='42.62.96.116'
zabbix_proxy_server_ip=$2
#zabbix_agent_ip=$(/sbin/ifconfig|grep 'inet addr:'|grep -Ev '127.0.0.1' | cut -d: -f2 | awk '{if ($1~/^10.*/) {print $1} else {print $1}}'|head -n 1)
zabbix_agent_ip=$(/sbin/ip addr|grep -w "inet"|grep -v 127.0.0.1|awk -F/ '{print $1}'|awk '{print $2}'|head -n 1)
#zabbix_proxy_agent_ip=$(/sbin/ip addr|grep -w "inet"|grep -v 127.0.0.1|awk -F/ '{print $1}'|awk '{print $2}'|grep -E "172|10"|tail -n 1)
#zabbix_agent_header=$(/sbin/ifconfig|grep 'inet addr:'|grep -Ev '127.0.0.1' | cut -d: -f2 | awk '{if ($1~/^10.*/) {print $1} else {print $1}}'|head -n 1|cut -d . -f1)
#zabbix_agent_header=$(/sbin/ip addr|grep -w "inet"|grep -v 127.0.0.1|awk -F/ '{print $1}'|awk '{print $2}'|head -n 1)
#zabbix_agent_ip=$(curl -s http://myip.ksyun.com/get.php|awk -F[\"] '{print $4}')


#############Check agent IP#################
#function check_ip() {

#public=`/sbin/ip addr|grep -w "inet"|grep -v 127.0.0.1|awk -F/ '{print $1}'|awk '{print $2}'|grep -Ev "172.*|10.*|192.168.*"|tail -n 1`
#if [ ! -z $public  ];then
#        zabbix_agent_ip=$public
#    else
#        zabbix_agent_ip=`/sbin/ip addr|grep -w "inet"|grep -v 127.0.0.1|awk -F/ '{print $1}'|awk '{print $2}'|tail -n 1`
#fi
#}
#############Check selinux status#############
function check_selinux() {
if [[ $(getenforce|grep -w "Enforcing"|wc -l) = 1 ]];then
     echo -e "\033[1;31mYour system's Selinux is enforced!Now must be disabled....\033[0m"
     setenforce 0
     sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/selinux/config
     echo -e "\033[1;32mSelinux is disabled Now!\033[0m"
   else
     echo -e "\033[1;32mSelinux had been disabled,there is no need to be modified!\033[0m"
fi
}

#############Check OS version and change dash for Ubuntu##################
function modify_dash() {
if [[ $(uname -a|grep -E "el6|el5|el7|debian"|wc -l) = 1 ]];then
     echo "OK.bash is default!"
   else
     echo "Ubuntu system must modify dash!"
     ln -s /bin/bash /bin/sh 2>/dev/null
     echo "link created success!"
fi
}

#############Check if running script's user is root######################
function install_zabbix_agent() {
if [ $(id -u) != "0" ]; then
    echo -e "\033[1;31m Error: You must be root to run this script!\033[0m"
    exit 1
fi

###############check network#####################
#ping -c 2 www.baidu.com >>/dev/null 2>&1
#if [ $? -ne 0 ];then
#    echo -e "\033[1;31m Error: The host can't connect to Inetnet!\033[0m"

#fi

################install zabbix##############

system_version=$(uname -m)

if [[ $(grep -i -E -c -w "Red|CentOS" /etc/issue) = 1 ]] && [[ $(grep -i -c "release 6" /etc/issue) = 1 ]];then
   if [ $system_version == 'x86_64' ];then
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el6.x86_64.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el6.x86_64.rpm
      rm -rf zabbix-2.2.4-1.el6.x86_64.rpm
      rm -rf zabbix-agent-2.2.4-1.el6.x86_64.rpm
      chkconfig zabbix-agent on
   else
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el6.i386.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el6.i386.rpm
      rm -rf zabbix-2.2.4-1.el6.i386.rpm
      rm -rf zabbix-agent-2.2.4-1.el6.i386.rpm
      chkconfig zabbix-agent on
   fi
    
elif [[ $(grep -i -E -c -w "Red|CentOS" /etc/issue) = 1 ]] && [[ $(grep -i -c "release 5" /etc/issue) = 1 ]];then
    if [ $system_version == 'x86_64' ];then
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el5.x86_64.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el5.x86_64.rpm
      rm -rf zabbix-2.2.4-1.el5.x86_64.rpm
      rm -rf zabbix-agent-2.2.4-1.el5.x86_64.rpm
      chkconfig zabbix-agent on
    else
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el5.i386.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el5.i386.rpm
      rm -rf zabbix-2.2.4-1.el5.i386.rpm
      rm -rf zabbix-agent-2.2.4-1.el5.i386.rpm
      chkconfig zabbix-agent on
    fi
elif [[ $(grep -i -E -c -w "Red|CentOS"  /etc/redhat-release) = 1 ]] && [[ $(grep -i -c "release 7" /etc/redhat-release) = 1 ]];then
    if [ $system_version == 'x86_64' ];then
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.7-2.el7.x86_64.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.7-2.el7.x86_64.rpm
      rm -rf zabbix-2.2.7-2.el7.x86_64.rpm
      rm -rf zabbix-agent-2.2.7-2.el7.x86_64.rpm
      chkconfig zabbix-agent on
    fi	
elif [[ $(grep -i -c "ubuntu" /etc/issue) = 1 ]];then
     if [ $(grep -i -c "ubuntu 12" /etc/issue) == 1 ];then
       wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+precise_all.deb
       dpkg -i zabbix-release_2.2-1+precise_all.deb
       #apt-get update
       apt-get install zabbix-agent
       rm -rf zabbix-release_2.2-1+precise_all.deb
     else
       wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+trusty_all.deb
       dpkg -i zabbix-release_2.2-1+trusty_all.deb
       #apt-get update
       apt-get install zabbix-agent
       rm -rf zabbix-release_2.2-1+trusty_all.deb
     fi
else
      if [ $(grep -i -c "Debian GNU/Linux 6" /etc/issue) == 1 ];then
        wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+squeeze_all.deb
        dpkg -i zabbix-release_2.2-1+squeeze_all.deb
        #apt-get update
        apt-get install zabbix-agent
        rm -rf zabbix-release_2.2-1+squeeze_all.deb
      else
        wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+wheezy_all.deb
        dpkg -i zabbix-release_2.2-1+wheezy_all.deb
        #apt-get update
        apt-get install zabbix-agent
        rm -rf zabbix-release_2.2-1+wheezy_all.deb
      fi
fi

################mondiy zabbix agent conf###################
sed -i 's/LogFileSize=0/LogFileSize=1/g' /etc/zabbix/zabbix_agentd.conf
sed -i 's/Server=127.0.0.1/Server='${zabbix_server_ip}'/g' /etc/zabbix/zabbix_agentd.conf
sed -i 's/ServerActive=127.0.0.1/ServerActive='${zabbix_server_ip}:10051'/g' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# Timeout=3/a Timeout=30' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# UnsafeUserParameters=0/a UnsafeUserParameters=1' /etc/zabbix/zabbix_agentd.conf
sed -i 's#Hostname=Zabbix server#Hostname='$zabbix_agent_hostname'#' /etc/zabbix/zabbix_agentd.conf
sed -i 's@# SourceIP=@SourceIP='$zabbix_agent_ip'@' /etc/zabbix/zabbix_agentd.conf

#################If you monitor MysqlDB######################
echo -e "\033[1;31mIf you want to monitor mysql,please grant priveleges as follow:\033[0m"
echo -e "\033[1;31mGrant SELECT, SUPER ON *.* TO 'zabbix'@'localhost' IDENTIFIED BY 'King+5688';\033[0m"
#################setting sudo priority######################
chmod +w /etc/sudoers 
sed -i 's/^\(Defaults\s\+requiretty\)/#\1/' /etc/sudoers
echo 'zabbix ALL=(ALL)       NOPASSWD: ALL' >> /etc/sudoers
chmod 440 /etc/sudoers
###############set discovery disk io########################
cat >>/etc/zabbix/zabbix_agentd.conf<<EOF
UserParameter=custom.vfs.dev.discovery,/bin/sh /etc/zabbix/externalscripts/disk.sh
# reads completed successfully
UserParameter=custom.vfs.dev.read.ops[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$4}'
# sectors read
UserParameter=custom.vfs.dev.read.sectors[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$6}'
# time spent reading (ms)
UserParameter=custom.vfs.dev.read.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$7}'
# writes completed
UserParameter=custom.vfs.dev.write.ops[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$8}'
# sectors written
UserParameter=custom.vfs.dev.write.sectors[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$10}'
# time spent writing (ms)
UserParameter=custom.vfs.dev.write.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$11}'
# I/Os currently in progress
UserParameter=custom.vfs.dev.io.active[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$12}'
# time spent doing I/Os (ms)
UserParameter=custom.vfs.dev.io.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$13}'
UserParameter=custom.vfs.dev.io.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$13}'
UserParameter=tcp.connect[*],/bin/bash /etc/zabbix/externalscripts/monitor-tcp.sh \$1
UserParameter=nginx[*],/bin/bash /etc/zabbix/externalscripts/monitor-nginx.sh \$1
UserParameter=php-fpm[*],/bin/bash /etc/zabbix/externalscripts/monitor-fpm.sh \$1
#monitor mysql
UserParameter=mysql.backup[*],cat /data/backup/dumperr.log 
#discovery mysql
UserParameter=mysql_port_discovery[*],/bin/bash /etc/zabbix/externalscripts/mysql_port_discovery.sh \$1
UserParameter=mysql_status[*],/bin/bash /etc/zabbix/externalscripts/monitor-multi-mysql.sh \$1 \$2
UserParameter=mysql_slave_status[*],/bin/bash /etc/zabbix/externalscripts/monitor-slave-status.sh \$1 \$2
UserParameter=mysql_ping[*],/bin/bash  /etc/zabbix/externalscripts/monitor-mysql-alive.sh \$1
#monitor redis
UserParameter=custom.redis.discovery[*],/bin/bash /etc/zabbix/externalscripts/monitor-redis.sh \$1
UserParameter=redis_stats[*],/usr/local/bin/redis-cli -p \$1 info|grep \$2|cut -d : -f2
#monitor mongoDB
UserParameter=MongoDB.Status[*],/bin/echo "db.serverStatus().\$1" | /usr/local/sbin/mongo admin | grep "\$2"|awk -F: '{print \$\$2}'|awk -F, '{print \$\$1}'
#monitor firewall status
UserParameter=firewall.status[*],/sbin/service iptables status 1\$>/dev/null 2\$>\$&1 \$&\$& echo \$\$?
#people info for game
UserParameter=xsj.gs.people[*],netstat -ant|grep -w '\$1'|grep -v LISTEN|wc -l
UserParameter=custom.process.discovery,/bin/sh /etc/zabbix/externalscripts/gameprocess.sh
# discovery game process
UserParameter=custom.game.process.num[*],ps xua|grep -w "\$1"|grep -v grep|wc -l
UserParameter=custom.game.process.cpu[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$3}'
UserParameter=custom.game.process.mem[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$4}'
UserParameter=custom.game.process.vsz.mem[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$5}'
UserParameter=custom.game.process.rss.mem[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$6}'
#monitor disk media status
UserParameter=custom.disk.media.discovery,/bin/sh /etc/zabbix/externalscripts/disk-media.sh
# reads completed successfully
UserParameter=custom.disk.media.status[*],hpssacli ctrl all show config|grep physicaldrive|egrep \$1|awk -F[\)] '{print \$\$1}'|awk -F, '{print \$\$4}'
UserParameter=custom.mha.discovery,/bin/sh /etc/zabbix/externalscripts/monitor-mha.sh
UserParameter=custom.mha.num[*],ps xua|grep \$1|grep -v grep |wc -l
EOF

mkdir -p /etc/zabbix/externalscripts/
###############set monitor gameprocess########################
cat >/etc/zabbix/externalscripts/gameprocess.sh <<EOF
#!/bin/bash
#gameprocess=(\`ps xua|grep -E "jx3gameserver*|KG_CSLogServerD|KG_AuctionServer|SO3GameCenterD|SO3CustomRecordingServerD|SO3TongServerD|SO3AFKAccountListServerD|SO3MailServerD|JX3FellowshipSystem|SO3PushFellowshipD|SO3FireWallServerD|SO3GatewayD"|grep -v grep|awk -F[/] '{print \$2}'|awk '{print \$1}'   2>/dev/null\`)
gameprocess=(\`ps xua|grep -E "jx3gameserver*|KG_CSLogServerD|KG_AuctionServer|SO3GameCenterD|SO3CustomRecordingServerD|SO3TongServerD|SO3AFKAccountListServerD|SO3MailServerD|JX3FellowshipSystem|SO3PushFellowshipD|SO3FireWallServerD|SO3GatewayD|ZoneAccountServerD|AvatarServerD|WebModuleServerD|DataCenterServerD|jx3battlefieldserver*|SO3FellowshipRankServerD|SO3ZoneAccountAgencyD|ZoneServerD|SO3ArenaServerD|SO3CaptchaServerD|AccountSecurityServerD|SO3GlobalCounterServerD"|grep -v grep|awk -F[/] '{print \$2}'|awk '{print \$1}'   2>/dev/null\`)

length1=\${#gameprocess[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length1;i++))
do
        printf '\n\t\t{'
        printf "\"{#GAMEPROCESS}\":\"\${gameprocess[\$i]}\"}"
        if [ \$i -lt \$[\$length1-1] ];then
                printf ','
        fi
done
printf  "\n\t]\n"
printf "}\n"
EOF
###############set monitor tcp########################
cat >/etc/zabbix/externalscripts/monitor-tcp.sh <<EOF
#!/bin/bash

# function:monitor tcp connect status from zabbix

source /etc/bashrc >/dev/null 2>&1
source /etc/profile  >/dev/null 2>&1
LOG_FILE=/var/log/zabbix/tcp_connect.log
Log_dir=/var/log/zabbix/

if [ ! -d "\$Log_dir" ]; then
   mkdir -p /var/log/zabbix
fi

sudo netstat -n|awk '/^tcp/ {++S[\$NF]} END {for (a in S) print a,S[a]}'>\${LOG_FILE}
Permission=\$(ls -l \${LOG_FILE} |awk '{print \$3}')
[ "\$Permission" != zabbix ] && chown  zabbix.zabbix /var/log/zabbix/*

#Functions to return tcp connect status

established () {
        VALUE=\$(awk  '/ESTABLISHED/ {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}
listen () {
        VALUE=\$(awk  '/LISTEN/ {print \$2}'      \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}
timewait () {
        VALUE=\$(awk  '/TIME_WAIT/   {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}
timeclose () {
        VALUE=\$(awk  '/TIME_CLOSE/  {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}
finwait1 () {
        VALUE=\$(awk  '/FIN_WAIT1/   {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}

finwait2 () {
        VALUE=\$(awk  '/FIN_WAIT2/   {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}

synsent () {
        VALUE=\$(awk  '/SYN_SENT/    {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}
synrecv () {
        VALUE=\$(awk  '/SYN_RECV/    {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}
closewait () { 
        VALUE=\$(awk  '/CLOSE_WAIT/  {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}

# Run the requested function
case "\$1" in
established)
established
;;
listen)
listen
;;
timewait)
timewait
;;
timeclose)
timeclose
;;
finwait1)
finwait1
;;
finwait2)
finwait2
;;
synsent)
synsent
;;
synrecv)
synrecv
;;
closewait)
closewait
;;
*)
 echo "Usage: \$0 { established|listen|timewait|timeclose|finwait1|finwait2|synsent|synrecv|closewait}"
;;
esac
EOF
cat >/etc/zabbix/externalscripts/disk.sh <<EOF
#!/bin/bash
diskarray=(\`cat /proc/diskstats |grep -E "\bvd[a-z]\b|\bhd[a-z]\b|\bsd[a-z]\b|\bc0d0p[0-9]\b"|grep -i "\b\$1\b"|awk '{print \$3}'|sort|uniq   2>/dev/null\`)
length2=\${#diskarray[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length2;i++))
do
    printf '\n\t\t{'
    printf "\"{#DISK}\":\"\${diskarray[\$i]}\"}"
    if [ \$i -lt \$[\$length2-1] ];then
            printf ','
    fi
done
printf  "\n\t]\n"
printf "}\n"
EOF

####################set monitor mysql mha###########################
cat > /etc/zabbix/externalscripts/monitor-mha.sh << EOF
#!/bin/bash
mhaarray=(\`ps xua|grep masterha_manager|grep -v grep|awk -F[=] '{print $2}'|awk -F[/] '{print \$6}'|awk '{print \$1}'|awk -F[.] '{print \$1}'  2>/dev/null\`)
length=\${#mhaarray[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length;i++))
do
    printf '\n\t\t{'
    printf "\"{#MHA}\":\"\${mhaarray[\$i]}\"}"
    if [ \$i -lt \$[\$length-1] ];then
            printf ','
    fi
done
printf  "\n\t]\n"
printf "}\n"
EOF
cat >/etc/zabbix/externalscripts/disk-media.sh <<EOF
#!/bin/bash
diskarray=(\`sudo hpssacli ctrl all show config|grep physicaldrive|awk '{print \$2}'   2>/dev/null\`)
length2=\${#diskarray[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length2;i++))
do
    printf '\n\t\t{'
    printf "\"{#DISKMEDIA}\":\"\${diskarray[\$i]}\"}"
    if [ \$i -lt \$[\$length2-1] ];then
            printf ','
    fi
done
printf  "\n\t]\n"
printf "}\n"
EOF
###############set monitor redis########################
cat >/etc/zabbix/externalscripts/monitor-redis.sh <<EOF
#!/bin/bash
#Fucation: mysql low-level discovery
#Script_name: mysql_port_discovery.sh
redis() {
    port=(\`sudo /bin/netstat -tpln | awk -F "[ :]+" 'BEGIN {IGNORECASE=1; } /redis/ && /127.0.0.1/ {print \$5}'\`)
    max_index=\$[\${#port[@]}-1]
    printf '{\n'
    printf '\t"data":['
    for key in \`seq -s' ' 0 \$max_index\`
    do
        printf '\n\t\t{'
        printf "\"{#REDISPORT}\":\"\${port[\${key}]}\"}"
        if [ \$key -ne \$max_index ];then
            printf ","
        fi

    done
    printf '\n\t]\n'
    printf '}\n'
}
\$1
EOF
###############set monitor nginx########################
cat >/etc/zabbix/externalscripts/monitor-nginx.sh <<EOF
#!/bin/bash

function active {
                curl -s "http://127.0.0.1:8080/nginxstatus" | grep 'Active' | awk '{print \$3}'
}
function reading {
                curl -s "http://127.0.0.1:8080/nginxstatus" | grep 'Reading' | awk '{print \$2}'
}
function writing {
                curl -s "http://127.0.0.1:8080/nginxstatus" | grep 'Writing' | awk '{print \$4}'
}
function waiting {
                curl -s "http://127.0.0.1:8080/nginxstatus" | grep 'Waiting' | awk '{print \$6}'
}
function accepts {
                curl -s "http://127.0.0.1:8080/nginxstatus" | awk NR==3 | awk '{print \$1}'
}
function handled {
                curl -s "http://127.0.0.1:8080/nginxstatus" | awk NR==3 | awk '{print \$2}'
}
function requests {
                curl -s "http://127.0.0.1:8080/nginxstatus" | awk NR==3 | awk '{print \$3}'
}



case "\$1" in
active)
active
;;
reading)
reading 
;;
writing)
writing 
;;
waiting)
waiting 
;;
accepts)
accepts 
;;
handled)
handled 
;;
requests)
requests
;;
*)
 echo "Usage: \$0 {active|reading|writing|waiting|accepts|handled|requests}"
esac
EOF
cat >/etc/zabbix/externalscripts/monitor-fpm.sh <<EOF
#!/bin/bash
pool(){
     curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/pool/ {print \$NF}'
}        
process_manager() {        
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/process manager/ {print \$NF}'
}  

start_since(){
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^start since:/ {print \$NF}'
}
accepted_conn(){
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^accepted conn:/ {print \$NF}' 
}
listen_queue(){     
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^listen queue:/ {print \$NF}'
}
max_listen_queue(){
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^max listen queue:/ {print \$NF}'
}
listen_queue_len(){  
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^listen queue len:/ {print \$NF}'
}
idle_processes(){
   curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^idle processes:/ {print \$NF}'
}
active_processes(){
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^active processes:/ {print \$NF}'
}
total_processes(){
   curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^total processes:/ {print \$NF}' 
}
max_active_processes(){
   curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^max active processes:/ {print \$NF}'
}
max_children_reached(){
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^max children reached:/ {print \$NF}' 
}
case "\$1" in
pool)
pool
;;
process_manager)
process_manager
;;
start_since)
start_since
;;
accepted_conn)
accepted_conn
;;
listen_queue)
listen_queue
;;
max_listen_queue)
max_listen_queue
;;
listen_queue_len)
listen_queue_len
;;
idle_processes)
idle_processes
;;
active_processes)
active_processes
;;
total_processes)
total_processes
;;
max_active_processes)
max_active_processes
;;
max_children_reached)
max_children_reached
;;
*)
echo "Usage: \$0 {pool|process_manager|start_since|accepted_conn|listen_queue|max_listen_queue|listen_queue_len|idle_processes|active_processes|total_processes|max_active_processes|max_children_reached}"
esac
EOF
cat > /etc/zabbix/externalscripts/mysql_port_discovery.sh << EOF
#!/bin/bash
#Fucation: mysql low-level discovery
#Script_name: monitor-mysql.sh
mysql() {
    port1=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /mysql/ && /0.0.0.0/ {print \$5}'\`)
    port2=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /mysql/ {print \$4}'\`)
    if [ ! -n "\${port1}"  ];then
         port=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /mysql/ {print \$4}'\`)
    else
         port=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /mysql/ && /0.0.0.0/ {print \$5}'\`)
    fi
    max_index=\$[\${#port[@]}-1]
    printf '{\n'
    printf '\t"data":['
    for key in \`seq -s' ' 0 \$max_index\`
    do
        printf '\n\t\t{'
        printf "\"{#MYSQLPORT}\":\"\${port[\${key}]}\"}"
        if [ \$key -ne \$max_index ];then
            printf ","
        fi
    done
    printf '\n\t]\n'
    printf '}\n'
}
\$1
EOF
cat > /etc/zabbix/externalscripts/monitor-multi-mysql.sh << EOF
#!/bin/bash
#Fucation: mysql low-level discovery
#Script_name:monitor-multi-mysql.sh
socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'\`
#socket=\`ps xua|grep -w "socket"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'\`
mysqladmin -r ext -uzabbix -pKing+5688 -P \$1 -S \$socket |grep -w "\$2"|awk '{print \$4}'
#mysql -uzabbix -pKing+5688 -P \$1 -S \$socket  -e "show status"|grep -w "\$2"|awk '{print \$2}'
EOF
cat > /etc/zabbix/externalscripts/monitor-slave-status.sh << EOF
#!/bin/bash
#Fucation: monitor mysql slave status
#Script_name:monitor-slave-status.sh
socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'\`
#socket=\`ps xua|grep -w "socket"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'\` 
mysql -uzabbix -pKing+5688  -P \$1 -S \$socket -e "show slave status\G"|grep -w "\$2"|awk '{print \$2}'
EOF

cat > /etc/zabbix/externalscripts/monitor-mysql-alive.sh << EOF
#!/bin/bash    
#Fucation: monitor mysql slave status
#Script_name:monitor-slave-status.sh
socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'\`
mysqladmin -h localhost -P \$1 -S \$socket -uzabbix -pKing+5688 ping 2>/dev/null| grep -c alive
EOF

#########Disk monitor############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/disk.sh
chmod 755 /etc/zabbix/externalscripts/disk.sh
#########Redis monitor############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/monitor-redis.sh
chmod 755 /etc/zabbix/externalscripts/monitor-redis.sh
#########TCP connect monitor############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/monitor-tcp.sh
chmod 755 /etc/zabbix/externalscripts/monitor-tcp.sh
#########Nginx monitor############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/monitor-nginx.sh
chmod 755 /etc/zabbix/externalscripts/monitor-nginx.sh
#########Php-Fpm monitor############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/monitor-fpm.sh
chmod 755 /etc/zabbix/externalscripts/monitor-fpm.sh
#########Mysql multi instances monitor############
chmod 755 /etc/zabbix/externalscripts/mysql_port_discovery.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/mysql_port_discovery.sh
chmod 755 /etc/zabbix/externalscripts/monitor-multi-mysql.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/monitor-multi-mysql.sh
chmod 755 /etc/zabbix/externalscripts/monitor-slave-status.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/monitor-slave-status.sh
chmod 755 /etc/zabbix/externalscripts/monitor-mysql-alive.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/monitor-mysql-alive.sh
##########Monitor ssh login Failed###############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/secure.sh
chmod 755 /etc/zabbix/externalscripts/secure.sh
#########Game monitor############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/gameprocess.sh
chmod 755 /etc/zabbix/externalscripts/gameprocess.sh
 #########Oracle monitor############
easy_install cx_Oracle
easy_install argparse
cd /etc/zabbix/externalscripts && wget http://42.62.120.210:10086/base/rpm/pyora.py 
chown -R zabbix:zabbix /etc/zabbix/externalscripts/pyora.py
chmod 755 /etc/zabbix/externalscripts/pyora.py
#################monitor disk media#######################
chown -R zabbix:zabbix /etc/zabbix/externalscripts/disk-media.sh
chmod 755 /etc/zabbix/externalscripts/disk-media.sh
#################monitor mysql mha#######################
chown -R zabbix:zabbix /etc/zabbix/externalscripts/monitor-mha.sh
chmod 755 /etc/zabbix/externalscripts/monitor-mha.sh
########################add iptables for zabbix server/proxy###############
iptable_num=`iptables-save |grep ${zabbix_server_ip}|wc -l`

if [ ${iptable_num} -ge 1 ];then
echo -e "\033[1;31miptables had been added!\033[0m"
else
iptables -I INPUT 3 -s ${zabbix_server_ip}/32 -j ACCEPT
iptables-save >/etc/sysconfig/iptables
fi
echo -e "\033[1;31mCongratulations on you successful installation!\033[0m"
service zabbix-agent restart

}


function install_zabbix_proxy_agent() {

#############Check if running script's user is root######################
if [ $(id -u) != "0" ]; then
    echo -e "\033[1;31m Error: You must be root to run this script!\033[0m"
    exit 1
fi

###############check network#####################
#ping -c 2 www.baidu.com >>/dev/null 2>&1
#if [ $? -ne 0 ];then
#    echo -e "\033[1;31m Error: The host can't connect to Inetnet!Please check DNS setting!\033[0m"
#    exit 1
#fi
################set up zabbix##############

system_version=$(uname -m)

if [[ $(grep -i -E -c -w "KingOS|CentOS|Oracle|Red" /etc/issue) =  1 ]] && [[ $(grep -i -c "release 6" /etc/issue) = 1 ]];then
   if [ $system_version == 'x86_64' ];then
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el6.x86_64.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el6.x86_64.rpm
      rm -rf zabbix-2.2.4-1.el6.x86_64.rpm
      rm -rf zabbix-agent-2.2.4-1.el6.x86_64.rpm
      chkconfig zabbix-agent on
   else
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el6.i386.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el6.i386.rpm
      rm -rf zabbix-2.2.4-1.el6.i386.rpm
      rm -rf zabbix-agent-2.2.4-1.el6.i386.rpm
      chkconfig zabbix-agent on
   fi
    
elif [[ $(grep -i -E -c -w "CentOS|Oracle|Red" /etc/issue) = 1 ]] && [[ $(grep -i -c "release 5" /etc/issue) = 1 ]];then
    if [ $system_version == 'x86_64' ];then
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el5.x86_64.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el5.x86_64.rpm
      chkconfig zabbix-agent on
      rm -rf zabbix-2.2.4-1.el5.x86_64.rpm
      rm -rf zabbix-agent-2.2.4-1.el5.x86_64.rpm
    else
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.4-1.el5.i386.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.4-1.el5.i386.rpm
      chkconfig zabbix-agent on
      rm -rf zabbix-2.2.4-1.el5.i386.rpm
      rm -rf zabbix-agent-2.2.4-1.el5.i386.rpm
    fi
elif [[ $(grep -i -E -c -w "Red|CentOS|Oracle"  /etc/redhat-release) = 1 ]] && [[ $(grep -i -c "release 7" /etc/redhat-release) = 1 ]];then
    if [ $system_version == 'x86_64' ];then
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-2.2.7-2.el7.x86_64.rpm
      rpm -ivh http://42.62.120.210:10086/base/rpm/zabbix-agent-2.2.7-2.el7.x86_64.rpm
      chkconfig zabbix-agent on
      rm -rf zabbix-2.2.7-2.el7.x86_64.rpm
      rm -rf zabbix-agent-2.2.7-2.el7.x86_64.rpm
    #else
    #  echo "CentOS7 32bit!Please intall from source packages!"
    fi
elif [[ $(grep -i -E -c -w "CentOS|Oracle|Red" /etc/issue) = 1  ]] && [[ $(grep -i -c -E -w  "AS|release 4" /etc/issue) = 1  ]];then
     wget http://42.62.120.210:10086/base/rpm/install-zabbix-agent-2.2.4.tar.gz
     tar zxvf install-zabbix-agent-2.2.4.tar.gz
     /bin/bash agent_install.sh
     rm -rf install-zabbix-agent-2.2.4.tar.gz
     exit 0
elif [[ $(grep -i -c -w "ubuntu" /etc/issue) = 1 ]];then
     if [ $(grep -i -c "ubuntu 12" /etc/issue) == 1 ];then
       wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+precise_all.deb
       dpkg -i zabbix-release_2.2-1+precise_all.deb
       apt-get update
       apt-get install zabbix-agent
       rm -rf zabbix-release_2.2-1+precise_all.deb
     else
       wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+trusty_all.deb
       dpkg -i zabbix-release_2.2-1+trusty_all.deb
       apt-get update
       apt-get install zabbix-agent
       rm -rf zabbix-release_2.2-1+trusty_all.deb
     fi
else
      if [ $(grep -i -c -w "Debian GNU/Linux 6" /etc/issue) == 1 ];then
        wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+squeeze_all.deb
        dpkg -i zabbix-release_2.2-1+squeeze_all.deb
        apt-get update
        apt-get install zabbix-agent
        rm -rf zabbix-release_2.2-1+squeeze_all.deb
      else
        wget http://42.62.120.210:10086/base/rpm/zabbix-release_2.2-1+wheezy_all.deb
        dpkg -i zabbix-release_2.2-1+wheezy_all.deb
        apt-get update
        apt-get install zabbix-agent
        rm -rf zabbix-release_2.2-1+wheezy_all.deb
      fi
fi

################mondiy zabbix agent conf###################
sed -i 's/LogFileSize=0/LogFileSize=1/g' /etc/zabbix/zabbix_agentd.conf
sed -i 's/Server=127.0.0.1/Server='${zabbix_proxy_server_ip},${zabbix_server_ip}'/g' /etc/zabbix/zabbix_agentd.conf
sed -i 's/ServerActive=127.0.0.1/ServerActive='${zabbix_proxy_server_ip}:10051,${zabbix_server_ip}:10051'/g' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# Timeout=3/a Timeout=30' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# UnsafeUserParameters=0/a UnsafeUserParameters=1' /etc/zabbix/zabbix_agentd.conf
sed -i 's#Hostname=Zabbix server#Hostname='$zabbix_agent_ip'#' /etc/zabbix/zabbix_agentd.conf
#sed -i 's@# SourceIP=@SourceIP='$zabbix_proxy_agent_ip'@' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# HostMetadataItem=/a HostMetadataItem=system.uname' /etc/zabbix/zabbix_agentd.conf
#################If you monitor MysqlDB######################
echo -e "If you want to monitor mysql,please grant priveleges as follow:"
echo -e "Grant SELECT, SUPER ON *.* TO 'zabbix'@'localhost' IDENTIFIED BY '88888888';"
#################setting sudo priority######################
chmod +w /etc/sudoers 
sed -i 's/^\(Defaults\s\+requiretty\)/#\1/' /etc/sudoers
echo 'zabbix ALL=(ALL)       NOPASSWD: ALL' >> /etc/sudoers
chmod 440 /etc/sudoers
###############set discovery disk io########################

cat >>/etc/zabbix/zabbix_agentd.conf<<EOF
UserParameter=custom.vfs.dev.discovery,/bin/sh /etc/zabbix/externalscripts/disk.sh
# reads completed successfully
UserParameter=custom.vfs.dev.read.ops[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$4}'
# sectors read
UserParameter=custom.vfs.dev.read.sectors[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$6}'
# time spent reading (ms)
UserParameter=custom.vfs.dev.read.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$7}'
# writes completed
UserParameter=custom.vfs.dev.write.ops[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$8}'
# sectors written
UserParameter=custom.vfs.dev.write.sectors[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$10}'
# time spent writing (ms)
UserParameter=custom.vfs.dev.write.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$11}'
# I/Os currently in progress
UserParameter=custom.vfs.dev.io.active[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$12}'
# time spent doing I/Os (ms)
UserParameter=custom.vfs.dev.io.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$13}'
UserParameter=custom.vfs.dev.util[*],iostat -x -d -c 1 1|egrep \$1|awk '{print \$\$12}'
#auto discovery ssh Failed
UserParameter=custom.ssh.failed.discovery, /bin/sh /etc/zabbix/externalscripts/secure.sh
UserParameter=custom.ssh.failed.num[*], cat /etc/zabbix/externalscripts/ssh_failed.txt | egrep \$1 | head -1 | awk -F[:] '{print \$\$2}'
UserParameter=tcp.connect[*],/bin/bash /etc/zabbix/externalscripts/monitor-tcp.sh \$1
UserParameter=nginx[*], /bin/bash /etc/zabbix/externalscripts/monitor-nginx.sh \$1
UserParameter=php-fpm[*], /bin/bash /etc/zabbix/externalscripts/monitor-fpm.sh \$1
#monitor Oracle
UserParameter=pyora[*],/etc/zabbix/externalscripts/pyora.py --username \$1 --password \$2 --address \$3 --database \$4 \$5 \$6 \$7 \$8
#monitor mysql
UserParameter=mysql.backup[*],cat /data/backup/dumperr.log 
UserParameter=mysql[*], /bin/bash /etc/zabbix/externalscripts/monitor-mysql.sh \$1
#discovery mysql
UserParameter=mysql_port_discovery[*], /bin/bash /etc/zabbix/externalscripts/mysql_port_discovery.sh \$1
UserParameter=mysql_status[*], /bin/bash /etc/zabbix/externalscripts/monitor-multi-mysql.sh \$1 \$2
UserParameter=mysql_slave_status[*], /bin/bash /etc/zabbix/externalscripts/monitor-slave-status.sh \$1 \$2
UserParameter=mysql_ping[*], /bin/bash  /etc/zabbix/externalscripts/monitor-mysql-alive.sh \$1
#monitor redis
UserParameter=custom.redis.discovery[*], /bin/bash /etc/zabbix/externalscripts/monitor-redis.sh \$1
UserParameter=redis_stats[*], /usr/local/bin/redis-cli -p \$1 info|grep \$2|cut -d : -f2
#monitor mongoDB
UserParameter=MongoDB.Status[*],/bin/echo "db.serverStatus().\$1" | /usr/local/sbin/mongo admin | grep "\$2"|awk -F: '{print \$\$2}'|awk -F, '{print \$\$1}'
UserParameter=firewall.status[*],/sbin/service iptables status 1\$>/dev/null 2\$>\$&1 \$&\$& echo \$\$?
#people info for game
UserParameter=xsj.gs.people[*], netstat -ant|grep -w '\$1'|grep -v LISTEN|wc -l
UserParameter=custom.process.discovery, /bin/sh /etc/zabbix/externalscripts/gameprocess.sh
# discovery game process
UserParameter=custom.game.process.num[*], ps xua|grep -w "\$1"|grep -v grep|wc -l
UserParameter=custom.game.process.cpu[*], ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$3}'
UserParameter=custom.game.process.mem[*], ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$4}'
UserParameter=custom.game.process.vsz.mem[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$5}'
UserParameter=custom.game.process.rss.mem[*],ps xua|grep -w "\$1"|grep -v grep|awk '{print \$\$6}'
#monitor disk media status
UserParameter=custom.disk.media.discovery,/bin/sh /etc/zabbix/externalscripts/disk-media.sh
# reads completed successfully
UserParameter=custom.disk.media.status[*],hpssacli ctrl all show config|grep physicaldrive|egrep \$1|awk -F[\)] '{print \$\$1}'|awk -F, '{print \$\$4}'
UserParameter=custom.mha.discovery,/bin/sh /etc/zabbix/externalscripts/monitor-mha.sh
UserParameter=custom.mha.num[*],ps xua|grep \$1|grep -v grep |wc -l
EOF
mkdir -p /etc/zabbix/externalscripts/

###############set monitor gameprocess########################
cat >/etc/zabbix/externalscripts/gameprocess.sh <<EOF
#!/bin/bash
gameprocess=(\`ps xua|grep -E "kg_goddess_linux|kg_cslogserver_linux|kg_bishopd_linux|gamecenter_linux|js_gameserver01|js_gameserver02|js_gameserver03|js_gameserver04|js_gameserver05|js_gameserver06|js_gameserver07"|awk -F"./" '{print \$2}'|awk '{print \$1}' 2>/dev/null\`)

length1=\${#gameprocess[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length1;i++))
do
        printf '\n\t\t{'
        printf "\"{#GAMEPROCESS}\":\"\${gameprocess[\$i]}\"}"
        if [ \$i -lt \$[\$length1-1] ];then
                printf ','
        fi
done
printf  "\n\t]\n"
printf "}\n"
EOF
####################set monitor mysql mha###########################
cat > /etc/zabbix/externalscripts/monitor-mha.sh << EOF
#!/bin/bash
mhaarray=(`ps xua|grep masterha_manager|grep -v grep|awk -F[=] '{print $2}'|awk -F[/] '{print \$6}'|awk '{print \$1}'|awk -F[.] '{print \$1}'  2>/dev/null`)
length=\${#mhaarray[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length;i++))
do
    printf '\n\t\t{'
    printf "\"{#MHA}\":\"\${mhaarray[\$i]}\"}"
    if [ \$i -lt \$[\$length-1] ];then
            printf ','
    fi
done
printf  "\n\t]\n"
printf "}\n"
EOF
###############set monitor tcp########################
cat >/etc/zabbix/externalscripts/monitor-tcp.sh <<EOF
#!/bin/bash

# function:monitor tcp connect status from zabbix

source /etc/bashrc >/dev/null 2>&1
source /etc/profile  >/dev/null 2>&1
LOG_FILE=/var/log/zabbix/tcp_connect.log
Log_dir=/var/log/zabbix/

if [ ! -d "\$Log_dir"  ]; then
       mkdir -p /var/log/zabbix
fi

sudo netstat -n|awk '/^tcp/ {++S[\$NF]} END {for (a in S) print a,S[a]}'>\${LOG_FILE}
Permission=\$(ls -l \${LOG_FILE} |awk '{print \$3}')
[ "\$Permission" != zabbix ] && chown  zabbix.zabbix /var/log/zabbix/*

#Functions to return tcp connect status

established () {
        VALUE=\$(awk  '/ESTABLISHED/ {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}
listen () {
        VALUE=\$(awk  '/LISTEN/ {print \$2}'      \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}
timewait () {
        VALUE=\$(awk  '/TIME_WAIT/   {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}
timeclose () {
        VALUE=\$(awk  '/TIME_CLOSE/  {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}
finwait1 () {
        VALUE=\$(awk  '/FIN_WAIT1/   {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}

finwait2 () {
        VALUE=\$(awk  '/FIN_WAIT2/   {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}

synsent () {
        VALUE=\$(awk  '/SYN_SENT/    {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}
synrecv () {
        VALUE=\$(awk  '/SYN_RECV/    {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}
closewait () { 
        VALUE=\$(awk  '/CLOSE_WAIT/  {print \$2}' \${LOG_FILE})
        [ "\${VALUE}" != "" ] && echo \${VALUE}|| echo 0
}

# Run the requested function
case "\$1" in
established)
established
;;
listen)
listen
;;
timewait)
timewait
;;
timeclose)
timeclose
;;
finwait1)
finwait1
;;
finwait2)
finwait2
;;
synsent)
synsent
;;
synrecv)
synrecv
;;
closewait)
closewait
;;
*)
 echo "Usage: \$0 { established|listen|timewait|timeclose|finwait1|finwait2|synsent|synrecv|closewait}"
;;
esac
EOF
cat >/etc/zabbix/externalscripts/disk.sh <<EOF
#!/bin/bash
diskarray=(\`cat /proc/diskstats |grep -E "\bvd[a-z]\b|\bhd[a-z]\b|\bsd[a-z]\b|\bc0d0p[0-9]\b"|grep -i "\b\$1\b"|awk '{print \$3}'|sort|uniq   2>/dev/null\`)
length2=\${#diskarray[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length2;i++))
do
    printf '\n\t\t{'
    printf "\"{#DISK}\":\"\${diskarray[\$i]}\"}"
    if [ \$i -lt \$[\$length2-1] ];then
            printf ','
    fi
done
printf  "\n\t]\n"
printf "}\n"
EOF


cat >/etc/zabbix/externalscripts/disk-media.sh <<EOF
#!/bin/bash
diskarray=(\`sudo hpssacli ctrl all show config|grep physicaldrive|awk '{print \$2}'   2>/dev/null\`)
length2=\${#diskarray[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length2;i++))
do
    printf '\n\t\t{'
    printf "\"{#DISKMEDIA}\":\"\${diskarray[\$i]}\"}"
    if [ \$i -lt \$[\$length2-1] ];then
            printf ','
    fi
done
printf  "\n\t]\n"
printf "}\n"
EOF

###############set monitor redis########################

cat >/etc/zabbix/externalscripts/monitor-redis.sh <<EOF
#!/bin/bash
#Fucation: mysql low-level discovery
#Script_name: mysql_port_discovery.sh
redis() {
    port1=(\`sudo /bin/netstat -tpln | awk -F "[ :]+" 'BEGIN {IGNORECASE=1; } /redis/ && /127.0.0.1/ {print \$5}'\`)
    port2=(\`sudo /bin/netstat -tpln | awk -F "[ :  ]+" 'BEGIN {IGNORECASE=1; } /mysql/ && /0.0.0.0/ {print \$5}'\`)
    
    if [ ! -n "\${port1}"   ];then
        port=(\`sudo /bin/netstat -tpln | awk -F "[ :   ]+" 'BEGIN {IGNORECASE=1; } /mysql/ && /0.0.0.0/ {print \$5}'\`)
    else
        port=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /redis/ && /127.0.0.1/ {print \$5}'\`)
    fi

    max_index=\$[\${#port[@]}-1]
    printf '{\n'
    printf '\t"data":['
    for key in \`seq -s' ' 0 \$max_index\`
    do
        printf '\n\t\t{'
        printf "\"{#REDISPORT}\":\"\${port[\${key}]}\"}"
        if [ \$key -ne \$max_index ];then
            printf ","
        fi

    done
    printf '\n\t]\n'
    printf '}\n'
}
\$1
EOF
###############set monitor nginx########################
cat >/etc/zabbix/externalscripts/monitor-nginx.sh <<EOF
#!/bin/bash

function active {
                curl -s "http://127.0.0.1:8080/nginxstatus" | grep 'Active' | awk '{print \$3}'
}
function reading {
                curl -s "http://127.0.0.1:8080/nginxstatus" | grep 'Reading' | awk '{print \$2}'
}
function writing {
                curl -s "http://127.0.0.1:8080/nginxstatus" | grep 'Writing' | awk '{print \$4}'
}
function waiting {
                curl -s "http://127.0.0.1:8080/nginxstatus" | grep 'Waiting' | awk '{print \$6}'
}
function accepts {
                curl -s "http://127.0.0.1:8080/nginxstatus" | awk NR==3 | awk '{print \$1}'
}
function handled {
                curl -s "http://127.0.0.1:8080/nginxstatus" | awk NR==3 | awk '{print \$2}'
}
function requests {
                curl -s "http://127.0.0.1:8080/nginxstatus" | awk NR==3 | awk '{print \$3}'
}



case "\$1" in
active)
active
;;
reading)
reading 
;;
writing)
writing 
;;
waiting)
waiting 
;;
accepts)
accepts 
;;
handled)
handled 
;;
requests)
requests
;;
*)
 echo "Usage: \$0 {active|reading|writing|waiting|accepts|handled|requests}"
esac
EOF
cat >/etc/zabbix/externalscripts/monitor-fpm.sh <<EOF
#!/bin/bash
pool(){
     curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/pool/ {print \$NF}'
}        
process_manager() {        
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/process manager/ {print \$NF}'
}  

start_since(){
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^start since:/ {print \$NF}'
}
accepted_conn(){
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^accepted conn:/ {print \$NF}' 
}
listen_queue(){     
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^listen queue:/ {print \$NF}'
}
max_listen_queue(){
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^max listen queue:/ {print \$NF}'
}
listen_queue_len(){  
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^listen queue len:/ {print \$NF}'
}
idle_processes(){
   curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^idle processes:/ {print \$NF}'
}
active_processes(){
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^active processes:/ {print \$NF}'
}
total_processes(){
   curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^total processes:/ {print \$NF}' 
}
max_active_processes(){
   curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^max active processes:/ {print \$NF}'
}
max_children_reached(){
    curl -s http://127.0.0.1:8080/phpfpmstatus|awk '/^max children reached:/ {print \$NF}' 
}
case "\$1" in
pool)
pool
;;
process_manager)
process_manager
;;
start_since)
start_since
;;
accepted_conn)
accepted_conn
;;
listen_queue)
listen_queue
;;
max_listen_queue)
max_listen_queue
;;
listen_queue_len)
listen_queue_len
;;
idle_processes)
idle_processes
;;
active_processes)
active_processes
;;
total_processes)
total_processes
;;
max_active_processes)
max_active_processes
;;
max_children_reached)
max_children_reached
;;
*)
echo "Usage: \$0 {pool|process_manager|start_since|accepted_conn|listen_queue|max_listen_queue|listen_queue_len|idle_processes|active_processes|total_processes|max_active_processes|max_children_reached}"
esac
EOF

cat > /etc/zabbix/externalscripts/mysql_port_discovery.sh << EOF
#!/bin/bash
#Fucation: mysql low-level discovery
#Script_name: monitor-mysql.sh
mysql() {
    port1=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /mysql/ && /0.0.0.0/ {print \$5}'\`)
    port2=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /mysql/ {print \$4}'\`)
    if [ ! -n "\${port1}"  ];then
         port=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /mysql/ {print \$4}'\`)
    else
         port=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /mysql/ && /0.0.0.0/ {print \$5}'\`)
    fi
    max_index=\$[\${#port[@]}-1]
    printf '{\n'
    printf '\t"data":['
    for key in \`seq -s' ' 0 \$max_index\`
    do
        printf '\n\t\t{'
        printf "\"{#MYSQLPORT}\":\"\${port[\${key}]}\"}"
        if [ \$key -ne \$max_index ];then
            printf ","
        fi
    done
    printf '\n\t]\n'
    printf '}\n'
}
\$1
EOF
cat > /etc/zabbix/externalscripts/monitor-multi-mysql.sh << EOF
#!/bin/bash
#Fucation: mysql low-level discovery
#Script_name:monitor-multi-mysql.sh
#judge one or multi 

one=\`ps xua|grep mysqld|grep -w "port=3306"|wc -l\`
if [ \$one -lt 1 ];then

    socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'|grep sock|head -n 1\`
    mysqladmin -r ext -uzabbix -pKing+5688 -P 3306 -S \$socket 2>/dev/null|grep -w "\$2"|awk '{print \$4}'

else

    socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep -w "port=\$1"|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'\`
    #socket=\`ps xua|grep -w "socket"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'\`
    mysqladmin -r ext -uzabbix -pKing+5688 -P \$1 -S \$socket 2>/dev/null|grep -w "\$2"|awk '{print \$4}'
    #mysql -uzabbix -pKing+5688 -P \$1 -S \$socket  -e "show status"|grep -w "\$2"|awk '{print \$2}'
fi
EOF
cat > /etc/zabbix/externalscripts/monitor-slave-status.sh << EOF
#!/bin/bash
#Fucation: monitor mysql slave status
#Script_name:monitor-slave-status.sh
one=\`ps xua|grep mysqld|grep -w "port=3306"|wc -l\` 

if [ \$one -lt 1  ];then 
    
    socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'|grep  sock|head -n 1\`
     mysql -uzabbix -pKing+5688  -P 3306 -S \$socket -e "show slave status\G" 2>/dev/null|grep -w "\$2"|awk '{print \$2}'
else
    socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep -w "port=\$1"|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'\`
    #socket=\`ps xua|grep -w "socket"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'\` 
    mysql -uzabbix -pKing+5688  -P \$1 -S \$socket -e "show slave status\G" 2>/dev/null|grep -w "\$2"|awk '{print \$2}'
fi
EOF

cat > /etc/zabbix/externalscripts/monitor-mysql-alive.sh << EOF
#!/bin/bash    
#Fucation: monitor mysql slave status
#Script_name:monitor-slave-status.sh
one=\`ps xua|grep mysqld|grep -w "port=3306"|wc -l\`

if [ \$one -lt 1   ];then 
    
    socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'|grep sock|head -n 1\`
     mysqladmin -h localhost -P 3306 -S \$socket -uzabbix -pKing+5688 ping 2>/dev/null| grep -c alive

else
    socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep -w "port=\$1"|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'\`
    mysqladmin -h localhost -P \$1 -S \$socket -uzabbix -pKing+5688 ping 2>/dev/null| grep -c alive
fi
EOF

cat >/etc/zabbix/externalscripts/secure.sh <<EOF
#!/bin/bash
cat /var/log/secure|awk '/Failed/{print \$(NF-3)}'|sort|uniq -c|awk '{print \$2":"\$1;}'  >ssh_failed.txt
chown -R zabbix:zabbix /etc/zabbix/externalscripts/ssh_failed.txt
ssharray=(\`cat /etc/zabbix/externalscripts/ssh_failed.txt|awk -F[:] '{print \$1}' 2>/dev/null\`)
length2=\${#ssharray[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length2;i++))
do
    printf '\n\t\t{'
    printf "\"{#SSHIP}\":\"\${ssharray[\$i]}\"}"
    if [ \$i -lt \$[\$length2-1] ];then
            printf ','
    fi
done
printf  "\n\t]\n"
printf "}\n"
EOF
#########Disk monitor############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/disk.sh
chmod 755 /etc/zabbix/externalscripts/disk.sh
#########Redis monitor############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/monitor-redis.sh
chmod 755 /etc/zabbix/externalscripts/monitor-redis.sh
#########TCP connect monitor############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/monitor-tcp.sh
chmod 755 /etc/zabbix/externalscripts/monitor-tcp.sh
#########Nginx monitor############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/monitor-nginx.sh
chmod 755 /etc/zabbix/externalscripts/monitor-nginx.sh
#########Php-Fpm monitor############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/monitor-fpm.sh
chmod 755 /etc/zabbix/externalscripts/monitor-fpm.sh
#########Mysql multi instances monitor############
chmod 755 /etc/zabbix/externalscripts/mysql_port_discovery.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/mysql_port_discovery.sh
chmod 755 /etc/zabbix/externalscripts/monitor-multi-mysql.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/monitor-multi-mysql.sh
chmod 755 /etc/zabbix/externalscripts/monitor-slave-status.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/monitor-slave-status.sh
chmod 755 /etc/zabbix/externalscripts/monitor-mysql-alive.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/monitor-mysql-alive.sh
##########Monitor ssh login Failed###############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/secure.sh
chmod 755 /etc/zabbix/externalscripts/secure.sh
#########Game monitor############
chown -R zabbix:zabbix /etc/zabbix/externalscripts/gameprocess.sh
chmod 755 /etc/zabbix/externalscripts/gameprocess.sh
 #########Oracle monitor############
#easy_install cx_Oracle
#easy_install argparse
#cd /etc/zabbix/externalscripts && wget http://42.62.120.210:10086/base/rpm/pyora.py 
#chown -R zabbix:zabbix /etc/zabbix/externalscripts/pyora.py
#chmod 755 /etc/zabbix/externalscripts/pyora.py
#################monitor disk media#######################
chown -R zabbix:zabbix /etc/zabbix/externalscripts/disk-media.sh
chmod 755 /etc/zabbix/externalscripts/disk-media.sh
#################monitor mysql mha#######################
chown -R zabbix:zabbix /etc/zabbix/externalscripts/monitor-mha.sh
chmod 755 /etc/zabbix/externalscripts/monitor-mha.sh
########################add iptables for zabbix server/proxy###############

iptable_num=`iptables-save |grep ${zabbix_proxy_server_ip}|wc -l`

if [ ${iptable_num} -ge 1 ];then
    echo "iptables had been added!"
else
    iptables -I INPUT 3 -s ${zabbix_proxy_server_ip}/32 -j ACCEPT
    iptables -I INPUT 4 -s ${zabbix_server_ip}/32 -j ACCEPT
    iptables-save >/etc/sysconfig/iptables
fi

########################add route to guangzhou for zabbix agent -> proxy###############
just_ip=`ip a|grep -w "205.252."|wc -l`

if [ ${just_ip} -ge 1 ];then
 route add -net 172.16.1.0 netmask 255.255.255.0 gw 172.30.0.2
else
    echo "ok"
fi

#################Backup old config###############
#cat  /etc/zabbix_agentd_om/etc/zabbix_agentd.conf |grep "UserParameter="|grep -v "#">> /etc/zabbix/zabbix_agentd.conf

#################restart agent###################
service zabbix-agent restart
echo -e "\033[1;31mCongratulations on your installation success!\033[0m"

}

function uninstall_zabbix_agent() {

################uninstall zabbix##############
if [ $(id -u) != "0" ]; then
    echo -e "\033[1;31m Error: You must be root to run this script!\033[0m"
    exit 1
fi
system_version=$(uname -m)

if [[ $(grep -i -E -c "CentOS|Oracle|Red" /etc/redhat-release) = 1 ]];then
      rpm -e zabbix-agent
      rpm -e zabbix
else [[ $(grep -E -c "Ubuntu|Debian" /etc/issue) = 1 ]]
       dpkg -P zabbix-agent
fi
 
      iptables -D INPUT -s ${zabbix_server_ip}/32 -j ACCEPT
      iptables -D INPUT -s ${zabbix_proxy_server_ip}/32 -j ACCEPT
}

case $1 in 
 install_agent)
        
        check_selinux
        modify_dash
        install_zabbix_agent
            ;;
 install_proxy_agent)
       
        check_selinux
        modify_dash
        install_zabbix_proxy_agent
		    ;;

 uninstall) 
        uninstall_zabbix_agent
            ;;			
  *) 
        echo "                                                    "
		echo "Usage:$0(install_agent|install_proxy_agent|uninstall)" 
		echo "NAME"
		echo "          used to install zabbix agent"
		echo "DESCRIPTION"
		echo "           install_agent:install zabbix agent"
		echo "           install_proxy_agent:install zabbix proxy agent"
		echo "           uninstall:unintall agent"
        ;; 
esac 
