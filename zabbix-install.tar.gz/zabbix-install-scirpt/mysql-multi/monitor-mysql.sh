#!/bin/sh 
#author qunxue
#version 0.1 
#script is used to monitor mysql informaiton
#update logs:
#1.add arguement and function at 2015/3/27

socket=`cat /etc/my.cnf |grep socket|head -n 1|awk '{print $3}'`
MYSQL_SOCK="${socket}"
MYSQL_USER="zabbix" 
MYSQL_PWD="King+5688"

ARGS=1 
if [ $# -ne "$ARGS" ];then 
    echo "Please input one arguement:" 
fi 

key_blocks_used=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'key_blocks_used';" 2>/dev/null|grep -v Value|awk '{print $2}'`
key_blocks_unused=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'key_blocks_unused';" 2>/dev/null|grep -v Value|awk '{print $2}'`

key_reads=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'key_reads';" 2>/dev/null| grep -v Value |awk '{print $2}'`
key_read_requests=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'key_read_requests';" 2>/dev/null| grep -v Value |awk '{print $2}'`

open_tables=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'open_tables';" 2>/dev/null| grep -v Value |awk '{print $2}'`
opened_tables=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'opened_tables';" 2>/dev/null| grep -v Value |awk '{print $2}'`

#open_tables=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'open_tables';" 2>/dev/null| grep -v Value |awk '{print $2}'`
table_open_cache=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show variables like 'table_open_cache';" 2>/dev/null| grep -v Value |awk '{print $2}'`

Qcache_free_blocks=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'Qcache_free_blocks';" 2>/dev/null| grep -v Value |awk '{print $2}'`
Qcache_total_blocks=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'Qcache_total_blocks';" 2>/dev/null| grep -v Value |awk '{print $2}'`

query_cache_size=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show variables like 'query_cache_size';" 2>/dev/null| grep -v Value |awk '{print $2}'`
Qcache_free_memory=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'Qcache_free_memory';" 2>/dev/null| grep -v Value |awk '{print $2}'`

Qcache_hits=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'Qcache_hits';" 2>/dev/null| grep -v Value |awk '{print $2}'`
Qcache_inserts=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'Qcache_inserts';" 2>/dev/null| grep -v Value |awk '{print $2}'`

Handler_read_rnd_next=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'Handler_read_rnd_next';" 2>/dev/null| grep -v Value |awk '{print $2}'`
com_select=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'com_select';" 2>/dev/null| grep -v Value |awk '{print $2}'`

open_files=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'open_files';" 2>/dev/null| grep -v Value |awk '{print $2}'`
open_files_limit=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show variables like 'open_files_limit';" 2>/dev/null| grep -v Value |awk '{print $2}'`

created_tmp_disk_tables=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'created_tmp_disk_tables';" 2>/dev/null| grep -v Value |awk '{print $2}'`
created_tmp_tables=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'created_tmp_tables';" 2>/dev/null| grep -v Value |awk '{print $2}'`

Max_used_connections=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'Max_used_connections';" 2>/dev/null| grep -v Value |awk '{print $2}'`
max_connections=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show variables like 'max_connections';" 2>/dev/null| grep -v Value |awk '{print $2}'`

Table_locks_immediate=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'Table_locks_immediate';" 2>/dev/null| grep -v Value |awk '{print $2}'`
table_locks_waited=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show status like 'table_locks_waited';" 2>/dev/null| grep -v Value |awk '{print $2}'`

case $1 in 
    Ping) 
        result=`mysqladmin -u${MYSQL_USER} -p${MYSQL_PWD} -S $MYSQL_SOCK ping 2>/dev/null|grep alive|wc -l` 
            echo $result 
            ;; 
    Threads) 
            result=`mysqladmin -u${MYSQL_USER} -p${MYSQL_PWD} -S $MYSQL_SOCK status 2>/dev/null|cut -f3 -d":"|cut -f1 -d"Q"` 
            echo $result 
            ;; 
    Questions) 
        result=`mysqladmin -u${MYSQL_USER} -p${MYSQL_PWD} -S $MYSQL_SOCK status 2>/dev/null|cut -f4 -d":"|cut -f1 -d"S"` 
                echo $result 
                ;; 
    Slowqueries) 
        result=`mysqladmin -u${MYSQL_USER} -p${MYSQL_PWD} -S $MYSQL_SOCK status 2>/dev/null|cut -f5 -d":"|cut -f1 -d"O"` 
                echo $result 
                ;; 
    Qps) 
        result=`mysqladmin -u${MYSQL_USER} -p${MYSQL_PWD} -S $MYSQL_SOCK status 2>/dev/null|cut -f9 -d":"|awk '{print $1}'` 
                echo $result 
                ;; 
    Key_buffer_size) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show variables like 'key_buffer_size';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
    Key_reads) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e  "show status like 'key_reads';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Key_read_requests) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'key_read_requests';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
    Key_blocks_used) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'key_blocks_used';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;          
        Key_blocks_unused) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'key_blocks_unused';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Innodb_buffer_pool_size) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show variables like 'innodb_buffer_pool_size';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Innodb_log_file_size) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show variables like 'innodb_log_file_size';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Innodb_log_buffer_size) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show variables like 'innodb_log_buffer_size';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Table_open_cache) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show variables like 'table_open_cache';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Open_tables) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'open_tables';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Opened_tables) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'opened_tables';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Thread_cache_size) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show variables like 'thread_cache_size';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Threads_cached) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e  "show status like 'Threads_cached';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Threads_connected) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Threads_connected';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Threads_created) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Threads_created';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Threads_running) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Threads_running';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Qcache_free_blocks) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Qcache_free_blocks';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Qcache_free_memory) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Qcache_free_memory';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Qcache_hits) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Qcache_hits';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Qcache_inserts) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Qcache_inserts';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Qcache_lowmem_prunes) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Qcache_lowmem_prunes';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Qcache_not_cached) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Qcache_not_cached';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Qcache_queries_in_cache) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Qcache_queries_in_cache';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Qcache_total_blocks) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Qcache_total_blocks';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Query_cache_limit) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show variables like 'query_cache_limit';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Query_cache_min_res_unit) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show variables like 'query_cache_min_res_unit';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Query_cache_size) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show variables like 'query_cache_size';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Sort_merge_passes) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Sort_merge_passes';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Sort_range) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Sort_range';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Sort_rows) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Sort_rows';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Sort_scan) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Sort_scan';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;; 
        Handler_read_first) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Handler_read_first';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Handler_read_key) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Handler_read_key';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Handler_read_next) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Handler_read_next';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Handler_read_prev) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Handler_read_prev';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Handler_read_rnd) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Handler_read_rnd';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Handler_read_rnd_next) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Handler_read_rnd_next';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Com_select) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'com_select';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Com_insert) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'com_insert';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Com_insert_select) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'com_insert_select';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Com_update) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'com_update';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Com_replace) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'com_replace';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Com_replace_select) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'com_replace_select';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Open_files) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'open_files';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Open_files_limit) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show variables like 'open_files_limit';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Created_tmp_disk_tables) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'created_tmp_disk_tables';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Created_tmp_tables) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'created_tmp_tables';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Max_connections) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show variables like 'max_connections';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Max_used_connections) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Max_used_connections';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Table_locks_immediate) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'Table_locks_immediate';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Table_locks_waited) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'table_locks_waited';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Engine_select) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -s -e "show status like 'created_tmp_disk_tables';" 2>/dev/null| grep -v Value |awk '{print $2}'` 
                echo $result 
                ;;
        Slave_IO_State) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD}  -e "show slave status\G" 2>/dev/null|grep Slave_IO_Running|grep Yes|wc -l` 
                echo $result 
                ;;
        Slave_SQL_State) 
        result=`mysql -u${MYSQL_USER} -p${MYSQL_PWD} -e "show slave status\G" 2>/dev/null|grep Slave_SQL_Running|grep Yes|wc -l` 
                echo $result 
                ;;
         Key_blocks_used_rate) 
           if [[ $key_blocks_unused -eq 0 ]];then
                echo "0"
                else
        echo "scale=3;$key_blocks_used/$key_blocks_unused"|bc -l|sed 's/^\./0&/'
                fi
            ;; 
        Key_cache_miss_rate) 
            if [[ $key_read_requests -eq 0 ]];then
                echo "0"
                else
        echo "scale=3;$key_reads/$key_read_requests"|bc -l|sed 's/^\./0&/'
                fi
            ;; 
        Open_tables_rate)
            if [[ $opened_tables -eq 0 ]];then
                echo "0"
                else
        echo "scale=3;$open_tables/$opened_tables"|bc -l|sed 's/^\./0&/'
                fi
            ;; 
        Table_open_cache_used_rate) 
            if [[ $table_open_cache -eq 0 ]];then
                echo "0"
                else
        echo "scale=3;$open_tables/$table_open_cache"|bc -l|sed 's/^\./0&/'
                fi
            ;; 
        Qcache_fragment_rate) 
            if [[ $Qcache_total_blocks -eq 0 ]];then
                echo "0"
                else
        echo "scale=3;$Qcache_free_blocks/$Qcache_total_blocks"|bc -l|sed 's/^\./0&/'
                fi
            ;; 
        Qcache_used_rate)
        if [[ $Qcache_free_memory -eq 0 ]];then
                echo "0"
                else
        echo "scale=3;$query_cache_size/$Qcache_free_memory"|bc -l|sed 's/^\./0&/'
                fi
            ;; 
        Qcache_hits_rate)
        if [[ $Qcache_inserts -eq 0 ]];then
                echo "0"
                else
        echo "scale=3;$Qcache_hits/$Qcache_inserts"|bc -l|sed 's/^\./0&/'
                fi
            ;; 
        Table_scan_rate)
        if [[ $com_select -eq 0 ]];then
                echo "0"
                else
        echo "scale=3;$Handler_read_rnd_next/$com_select"|bc -l|sed 's/^\./0&/'
                fi
            ;; 
        Open_files_rate)
        if [[ $open_files_limit -eq 0 ]];then
                echo "0"
                else
        echo "scale=3;$open_files/$open_files_limit"|bc -l|sed 's/^\./0&/'
                fi
            ;; 
        Created_tmp_disk_tables_rate)
        if [[ $created_tmp_tables -eq 0 ]];then
                echo "0"
                else
        echo "scale=3;$created_tmp_disk_tables/$created_tmp_tables"|bc -l|sed 's/^\./0&/'
                fi
            ;; 
        Max_connections_used_rate)
        if [[ $max_connections -eq 0 ]];then
                echo "0"
                else
        echo "scale=3;$Max_used_connections/$max_connections"|bc -l|sed 's/^\./0&/'
                fi
            ;; 
        Engine_select) 
            if [[ $table_locks_waited -eq 0 ]];then
                echo "0"
                else
        echo "scale=3;$Table_locks_immediate/$table_locks_waited"|bc -l|sed 's/^\./0&/'
                fi
            ;; 
        *) 
        echo "Usage:$0(Ping|Threads|Max_connections_used_rate|Created_tmp_disk_tables_rate|Com_rollback|Questions)" 
        ;; 
esac 
