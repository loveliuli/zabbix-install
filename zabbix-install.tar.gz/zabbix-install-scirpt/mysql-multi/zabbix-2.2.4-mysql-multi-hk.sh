#!/bin/bash
#author qunxue
#version 0.1
#update logs:
#1.add install/uninstall function at 2015/3/27
#2.change zabbix_agent_ip get method(CentOS7's ifconfig cmd is not worked! at 2015/3/30
#3.add install for CentOS7 Version at 2015/3/30

###set variables
zabbix_agent_hostname=$(hostname)
zabbix_server_port='10051'
zabbix_server_ip='42.62.96.116'
zabbix_proxy_server_ip=$2
#zabbix_agent_ip=$(/sbin/ifconfig|grep 'inet addr:'|grep -Ev '127.0.0.1' | cut -d: -f2 | awk '{if ($1~/^10.*/) {print $1} else {print $1}}'|head -n 1)
zabbix_agent_ip=$(/sbin/ip addr|grep -w "inet"|grep -v 127.0.0.1|awk -F/ '{print $1}'|awk '{print $2}'|head -n 1)
zabbix_proxy_agent_ip=$(/sbin/ip addr|grep -w "inet"|grep -v 127.0.0.1|awk -F/ '{print $1}'|awk '{print $2}'|grep -E "172"|tail -n 1)
#zabbix_agent_header=$(/sbin/ifconfig|grep 'inet addr:'|grep -Ev '127.0.0.1' | cut -d: -f2 | awk '{if ($1~/^10.*/) {print $1} else {print $1}}'|head -n 1|cut -d . -f1)
zabbix_agent_header=$(/sbin/ip addr|grep -w "inet"|grep -v 127.0.0.1|awk -F/ '{print $1}'|awk '{print $2}'|head -n 1)


#############Check OS version##################
function modify_dash() {
if [[ $(uname -a|grep -E "el6|el5|el7|debian"|wc -l) = 1 ]];then
     echo "OK."
   else
     echo "Ubuntu system must modify dash!"
     ln -s /bin/bash /bin/sh 2>/dev/null
     echo "link created success!"
fi
}
#############Check if user is root######################
function install_zabbix_agent() {
if [ $(id -u) != "0" ]; then
    echo -e "\033[1;31m Error: You must be root to run this script!\033[0m"
    exit 1
fi

###############check network#####################
ping -c 2 www.baidu.com >>/dev/null 2>&1
if [ $? -ne 0 ];then
    echo -e "\033[1;31m Error: The host can't connect to Inetnet!\033[0m"
    exit 1
fi
################set up zabbix##############

system_version=$(uname -m)

if [[ $(grep -i -c "CentOS" /etc/issue) = 1 ]] && [[ $(grep -i -c "release 6" /etc/issue) = 1 ]];then
   if [ $system_version == 'x86_64' ];then
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-2.2.4-1.el6.x86_64.rpm
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-agent-2.2.4-1.el6.x86_64.rpm
      chkconfig zabbix-agent on
   else
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-2.2.4-1.el6.i386.rpm
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-agent-2.2.4-1.el6.i386.rpm
      chkconfig zabbix-agent on
   fi
    
elif [[ $(grep -i -c "CentOS" /etc/issue) = 1 ]] && [[ $(grep -i -c "release 5" /etc/issue) = 1 ]];then
    if [ $system_version == 'x86_64' ];then
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-2.2.4-1.el5.x86_64.rpm
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-agent-2.2.4-1.el5.x86_64.rpm
      chkconfig zabbix-agent on
    else
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-2.2.4-1.el5.i386.rpm
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-agent-2.2.4-1.el5.i386.rpm
      chkconfig zabbix-agent on
    fi
elif [[ $(grep -i -c "CentOS"  /etc/redhat-release) = 1 ]] && [[ $(grep -i -c "release 7" /etc/redhat-release) = 1 ]];then
    if [ $system_version == 'x86_64' ];then
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-2.2.7-2.el7.x86_64.rpm
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-agent-2.2.7-2.el7.x86_64.rpm
      chkconfig zabbix-agent on
    else
      echo "CentOS7 32bit!Please intall from source packages!"
    fi	
elif [[ $(grep -i -c "ubuntu" /etc/issue) = 1 ]];then
     if [ $(grep -i -c "ubuntu 12" /etc/issue) == 1 ];then
       wget http://205.252.235.74:10086/base/rpm/zabbix-release_2.2-1+precise_all.deb
       dpkg -i zabbix-release_2.2-1+precise_all.deb
       #apt-get update
       apt-get install zabbix-agent
     else
       wget http://205.252.235.74:10086/base/rpm/zabbix-release_2.2-1+trusty_all.deb
       dpkg -i zabbix-release_2.2-1+trusty_all.deb
       #apt-get update
       apt-get install zabbix-agent
     fi
else
      if [ $(grep -i -c "Debian GNU/Linux 6" /etc/issue) == 1 ];then
        wget http://205.252.235.74:10086/base/rpm/zabbix-release_2.2-1+squeeze_all.deb
        dpkg -i zabbix-release_2.2-1+squeeze_all.deb
        #apt-get update
        apt-get install zabbix-agent
      else
        wget http://205.252.235.74:10086/base/rpm/zabbix-release_2.2-1+wheezy_all.deb
        dpkg -i zabbix-release_2.2-1+wheezy_all.deb
        #apt-get update
        apt-get install zabbix-agent
      fi
fi

################mondiy zabbix agent conf###################
sed -i 's/LogFileSize=0/LogFileSize=1/g' /etc/zabbix/zabbix_agentd.conf
sed -i 's/Server=127.0.0.1/Server='$zabbix_server_ip'/g' /etc/zabbix/zabbix_agentd.conf
sed -i 's/ServerActive=127.0.0.1/ServerActive='${zabbix_server_ip}:10051'/g' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# Timeout=3/a Timeout=30' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# UnsafeUserParameters=0/a UnsafeUserParameters=1' /etc/zabbix/zabbix_agentd.conf
sed -i 's#Hostname=Zabbix server#Hostname='$zabbix_agent_hostname'#' /etc/zabbix/zabbix_agentd.conf
#sed -i 's@# SourceIP=@SourceIP='$zabbix_agent_ip'@' /etc/zabbix/zabbix_agentd.conf


#################setting sudo priority######################
#sed -i 's/^Defaults.*.requiretty/#Defaults    requiretty/' /etc/sudoers
#echo "zabbix ALL=(ALL)       NOPASSWD: /etc/init.d/irqbalance start" >>/etc/sudoers
# �ֶ�MySQL��Ȩ������zabbix�˻�
echo "��������MySQLʵ��������zabbix�˻���ִ��> GRANT PROCESS ON *.* TO 'zabbix'@'127.0.0.1' identified BY 'zabbix';flush privileges;"
# ��Ȩzabbix�û�����������netstat����
chmod +w /etc/sudoers 
sed -i 's/^\(Defaults\s\+requiretty\)/#\1/' /etc/sudoers
grep -q '^zabbix ALL=(ALL).*netstat' /etc/sudoers || echo 'zabbix ALL=(ALL)       NOPASSWD: /bin/netstat' >> /etc/sudoers
chmod 440 /etc/sudoers
###############set discovery disk io########################
cat >>/etc/zabbix/zabbix_agentd.conf<<EOF
UserParameter=custom.vfs.dev.discovery,/bin/sh /etc/zabbix/externalscripts/disk.sh
# reads completed successfully
UserParameter=custom.vfs.dev.read.ops[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$4}'
# sectors read
UserParameter=custom.vfs.dev.read.sectors[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$6}'
# time spent reading (ms)
UserParameter=custom.vfs.dev.read.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$7}'
# writes completed
UserParameter=custom.vfs.dev.write.ops[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$8}'
# sectors written
UserParameter=custom.vfs.dev.write.sectors[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$10}'
# time spent writing (ms)
UserParameter=custom.vfs.dev.write.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$11}'
# I/Os currently in progress
UserParameter=custom.vfs.dev.io.active[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$12}'
# time spent doing I/Os (ms)
UserParameter=custom.vfs.dev.io.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$13}'
#discovery mysql
UserParameter=mysql_port_discovery[*],/bin/bash /etc/zabbix/externalscripts/mysql_port_discovery.sh \$1
UserParameter=mysql_status[*],mysql -h 127.0.0.1 -P \$1 -uzabbix -pKing+5688 -N -e "show global status  where Variable_name='\$2'" 2>/dev/null| cut -f2
UserParameter=mysql_ping[*],mysqladmin -h 127.0.0.1 -P \$1 -uzabbix -pKing+5688 ping 2>/dev/null| grep -c alive
EOF
mkdir -p /etc/zabbix/externalscripts/
cat > /etc/zabbix/externalscripts/mysql_port_discovery.sh << 'EOF'
#!/bin/bash
#Fucation: mysql low-level discovery
#Script_name: monitor-mysql.sh
mysql() {
    port=(`sudo /bin/netstat -tpln | awk -F "[ :]+" 'BEGIN {IGNORECASE=1; } /mysql/ && /0.0.0.0/ {print $5}'`)
    max_index=$[${#port[@]}-1]
    printf '{\n'
    printf '\t"data":['
    for key in `seq -s' ' 0 $max_index`
    do
        printf '\n\t\t{'
        printf "\"{#MYSQLPORT}\":\"${port[${key}]}\"}"
	if [ $key -ne $max_index ];then
            printf ","
        fi
    done
    printf '\n\t]\n'
    printf '}\n'
}
$1
EOF
chmod 755 /etc/zabbix/externalscripts/mysql_port_discovery.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/mysql_port_discovery.sh

cat >/etc/zabbix/externalscripts/disk.sh <<EOF
#!/bin/bash
diskarray=(\`cat /proc/diskstats |grep -E "\bvd[abcdefg]\b|\bsd[abcdefg]\b|\bc0d0p[0-9]\b"|grep -i "\b\$1\b"|awk '{print \$3}'|sort|uniq   2>/dev/null\`)
length=\${#diskarray[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length;i++))
do
    printf '\n\t\t{'
    printf "\"{#DISK}\":\"\${diskarray[\$i]}\"}"
    if [ \$i -lt \$[\$length-1] ];then
            printf ','
    fi
done
printf  "\n\t]\n"
printf "}\n"
EOF
chown -R zabbix:zabbix /etc/zabbix/externalscripts/disk.sh
chmod 755 /etc/zabbix/externalscripts/disk.sh


################set iptables##############
iptable_num=`iptables-save |grep ${zabbix_server_ip}|wc -l`

if [ ${iptable_num} -ge 1 ];then
echo "iptables had been added!"
else
iptables -I INPUT 3 -s ${zabbix_server_ip}/32 -j ACCEPT
iptables-save >/etc/sysconfig/iptables
fi
echo "Congratulations on your successful installation!"
service zabbix-agent restart

}


function install_zabbix_proxy_agent() {
if [ $(id -u) != "0" ]; then
    echo -e "\033[1;31m Error: You must be root to run this script!\033[0m"
    exit 1
fi

###############check network#####################
ping -c 2 www.baidu.com >>/dev/null 2>&1
if [ $? -ne 0 ];then
    echo -e "\033[1;31m Error: The host can't connect to Inetnet!\033[0m"
    exit 1
fi
################set up zabbix##############

system_version=$(uname -m)

if [[ $(grep -i -c "CentOS" /etc/issue) = 1 ]] && [[ $(grep -i -c "release 6" /etc/issue) = 1 ]];then
   if [ $system_version == 'x86_64' ];then
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-2.2.4-1.el6.x86_64.rpm
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-agent-2.2.4-1.el6.x86_64.rpm
      chkconfig zabbix-agent on
   else
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-2.2.4-1.el6.i386.rpm
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-agent-2.2.4-1.el6.i386.rpm
      chkconfig zabbix-agent on
   fi
    
elif [[ $(grep -i -c "CentOS" /etc/issue) = 1 ]] && [[ $(grep -i -c "release 5" /etc/issue) = 1 ]];then
    if [ $system_version == 'x86_64' ];then
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-2.2.4-1.el5.x86_64.rpm
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-agent-2.2.4-1.el5.x86_64.rpm
      chkconfig zabbix-agent on
    else
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-2.2.4-1.el5.i386.rpm
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-agent-2.2.4-1.el5.i386.rpm
      chkconfig zabbix-agent on
    fi
elif [[ $(grep -i -c "CentOS"  /etc/redhat-release) = 1 ]] && [[ $(grep -i -c "release 7" /etc/redhat-release) = 1 ]];then
    if [ $system_version == 'x86_64' ];then
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-2.2.7-2.el7.x86_64.rpm
      rpm -ivh http://205.252.235.74:10086/base/rpm/zabbix-agent-2.2.7-2.el7.x86_64.rpm
      chkconfig zabbix-agent on
    else
      echo "CentOS7 32bit!Please intall from source packages!"
    fi	
elif [[ $(grep -i -c "ubuntu" /etc/issue) = 1 ]];then
     if [ $(grep -i -c "ubuntu 12" /etc/issue) == 1 ];then
       wget http://205.252.235.74:10086/base/rpm/zabbix-release_2.2-1+precise_all.deb
       dpkg -i zabbix-release_2.2-1+precise_all.deb
       #apt-get update
       apt-get install zabbix-agent
     else
       wget http://205.252.235.74:10086/base/rpm/zabbix-release_2.2-1+trusty_all.deb
       dpkg -i zabbix-release_2.2-1+trusty_all.deb
       #apt-get update
       apt-get install zabbix-agent
     fi
else
      if [ $(grep -i -c "Debian GNU/Linux 6" /etc/issue) == 1 ];then
        wget http://205.252.235.74:10086/base/rpm/zabbix-release_2.2-1+squeeze_all.deb
        dpkg -i zabbix-release_2.2-1+squeeze_all.deb
        #apt-get update
        apt-get install zabbix-agent
      else
        wget http://205.252.235.74:10086/base/rpm/zabbix-release_2.2-1+wheezy_all.deb
        dpkg -i zabbix-release_2.2-1+wheezy_all.deb
        #apt-get update
        apt-get install zabbix-agent
      fi
fi

################mondiy zabbix agent conf###################
sed -i 's/LogFileSize=0/LogFileSize=1/g' /etc/zabbix/zabbix_agentd.conf
sed -i 's/Server=127.0.0.1/Server='$zabbix_proxy_server_ip'/g' /etc/zabbix/zabbix_agentd.conf
sed -i 's/ServerActive=127.0.0.1/ServerActive='${zabbix_proxy_server_ip}:10051'/g' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# Timeout=3/a Timeout=30' /etc/zabbix/zabbix_agentd.conf
sed -i '/\# UnsafeUserParameters=0/a UnsafeUserParameters=1' /etc/zabbix/zabbix_agentd.conf
sed -i 's#Hostname=Zabbix server#Hostname='$zabbix_agent_hostname'#' /etc/zabbix/zabbix_agentd.conf
#sed -i 's@# SourceIP=@SourceIP='$zabbix_proxy_agent_ip'@' /etc/zabbix/zabbix_agentd.conf


#################setting sudo priority######################
#sed -i 's/^Defaults.*.requiretty/#Defaults    requiretty/' /etc/sudoers
#echo "zabbix ALL=(ALL)       NOPASSWD: /etc/init.d/irqbalance start" >>/etc/sudoers
# �ֶ�MySQL��Ȩ������zabbix�˻�
echo "��������MySQLʵ��������zabbix�˻���ִ��> GRANT PROCESS ON *.* TO 'zabbix'@'localhost' identified BY 'zabbix';flush privileges;"
cp -a /usr/local/mysql/bin/mysqladmin /bin/
cp -a /usr/bin/mysqladmin /bin/
# ��Ȩzabbix�û�����������netstat����
chmod +w /etc/sudoers 
sed -i 's/^\(Defaults\s\+requiretty\)/#\1/' /etc/sudoers
grep -q '^zabbix ALL=(ALL).*netstat' /etc/sudoers || echo 'zabbix ALL=(ALL)       NOPASSWD: /bin/netstat' >> /etc/sudoers
chmod 440 /etc/sudoers
###############set discovery disk io########################
cat >>/etc/zabbix/zabbix_agentd.conf<<EOF
UserParameter=custom.vfs.dev.discovery,/bin/sh /etc/zabbix/externalscripts/disk.sh
# reads completed successfully
UserParameter=custom.vfs.dev.read.ops[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$4}'
# sectors read
UserParameter=custom.vfs.dev.read.sectors[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$6}'
# time spent reading (ms)
UserParameter=custom.vfs.dev.read.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$7}'
# writes completed
UserParameter=custom.vfs.dev.write.ops[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$8}'
# sectors written
UserParameter=custom.vfs.dev.write.sectors[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$10}'
# time spent writing (ms)
UserParameter=custom.vfs.dev.write.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$11}'
# I/Os currently in progress
UserParameter=custom.vfs.dev.io.active[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$12}'
# time spent doing I/Os (ms)
UserParameter=custom.vfs.dev.io.ms[*],cat /proc/diskstats | egrep \$1 | head -1 | awk '{print \$\$13}'
UserParameter=mysql.backup[*],cat /data/backup/dumperr.log 
#discovery mysql
UserParameter=mysql_port_discovery[*],/bin/bash /etc/zabbix/externalscripts/mysql_port_discovery.sh \$1
UserParameter=mysql_status[*],/bin/bash /etc/zabbix/externalscripts/monitor-multi-mysql.sh \$1 \$2
UserParameter=mysql_slave_status[*],/bin/bash /etc/zabbix/externalscripts/monitor-slave-status.sh \$1 \$2
UserParameter=mysql_ping[*],/bin/bash  /etc/zabbix/externalscripts/monitor-mysql-alive.sh \$1
UserParameter=custom.mha.discovery,/bin/sh /etc/zabbix/externalscripts/monitor-mha.sh
UserParameter=custom.mha.num[*],ps xua|grep \$1|grep -v grep |wc -l
EOF
mkdir -p /etc/zabbix/externalscripts/
cat > /etc/zabbix/externalscripts/mysql_port_discovery.sh << EOF
#!/bin/bash
#Fucation: mysql low-level discovery
#Script_name: monitor-mysql.sh
mysql() {
    port1=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /mysql/ && /0.0.0.0/ {print \$5}'\`)
    port2=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /mysql/ {print \$4}'\`)
    if [ ! -n "\${port1}"  ];then
         port=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /mysql/ {print \$4}'\`)
    else
         port=(\`sudo /bin/netstat -tpln | awk -F "[ : ]+" 'BEGIN {IGNORECASE=1; } /mysql/ && /0.0.0.0/ {print \$5}'\`)
    fi
    max_index=\$[\${#port[@]}-1]
    printf '{\n'
    printf '\t"data":['
    for key in \`seq -s' ' 0 \$max_index\`
    do
        printf '\n\t\t{'
        printf "\"{#MYSQLPORT}\":\"\${port[\${key}]}\"}"
        if [ \$key -ne \$max_index ];then
            printf ","
        fi
    done
    printf '\n\t]\n'
    printf '}\n'
}
\$1
EOF
cat > /etc/zabbix/externalscripts/monitor-mha.sh << EOF
#!/bin/bash
mhaarray=(`ps xua|grep masterha_manager|grep -v grep|awk -F[=] '{print $2}'|awk -F[/] '{print \$6}'|awk '{print \$1}'|awk -F[.] '{print \$1}'  2>/dev/null`)
length=\${#mhaarray[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length;i++))
do
    printf '\n\t\t{'
    printf "\"{#MHA}\":\"\${mhaarray[\$i]}\"}"
    if [ \$i -lt \$[\$length-1] ];then
            printf ','
    fi
done
printf  "\n\t]\n"
printf "}\n"
EOF
cat > /etc/zabbix/externalscripts/monitor-multi-mysql.sh << EOF
#!/bin/bash
#Fucation: mysql low-level discovery
#Script_name:monitor-multi-mysql.sh
socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'\`
#socket=\`ps xua|grep -w "socket"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'\`

if [ ! -n "\$socket" ]; then
socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep -v innobackupex|grep -v grep|awk -F"--socket=" '{print \$2}'|grep sock\`
else
    socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'\`
fi

#mysqladmin -r ext -uzabbix -pKing+5688 -P \$1 |grep -w "\$2"|awk '{print \$4}'
mysqladmin -r ext -uzabbix -pKing+5688 -P \$1 -S \$socket |grep -w "\$2"|awk '{print \$4}'
#mysql -uzabbix -pKing+5688 -P \$1 -S \$socket  -e "show status"|grep -w "\$2"|awk '{print \$2}'
EOF
cat > /etc/zabbix/externalscripts/monitor-slave-status.sh << EOF
#!/bin/bash
#Fucation: monitor mysql slave status
#Script_name:monitor-slave-status.sh
socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'\`
#socket=\`ps xua|grep -w "socket"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'\` 

if [ ! -n "\$socket" ]; then
socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep -v innobackupex|grep -v grep|awk -F"--socket=" '{print \$2}'|grep sock\`
else
socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'\`
fi

#mysql -h localhost -uzabbix -pKing+5688  -P \$1  -e "show slave status\G"|grep -w "\$2"|awk '{print \$2}'
mysql -uzabbix -pKing+5688  -P \$1 -S \$socket -e "show slave status\G"|grep -w "\$2"|awk '{print \$2}'
EOF

cat > /etc/zabbix/externalscripts/monitor-mysql-alive.sh << EOF
#!/bin/bash    
#Fucation: monitor mysql slave status
#Script_name:monitor-slave-status.sh
socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep -v innobackupex|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'\`

if [ ! -n "\$socket" ]; then
socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep -v innobackupex|grep -v grep|awk -F"--socket=" '{print \$2}'|grep sock\`
else
    socket=\`ps xua|grep -w "socket"|grep -v "mysqld_safe"|grep \$1|awk 'BEGIN {FS="--socket="} {print \$2}'|awk '{print \$1}'\`
fi

mysqladmin -h localhost -P \$1 -S \$socket -uzabbix -pKing+5688 ping 2>/dev/null| grep -c alive
#mysqladmin -h localhost -P \$1  -uzabbix -pKing+5688 ping 2>/dev/null| grep -c alive
EOF
chmod 755 /etc/zabbix/externalscripts/mysql_port_discovery.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/mysql_port_discovery.sh
chmod 755 /etc/zabbix/externalscripts/monitor-multi-mysql.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/monitor-multi-mysql.sh
chmod 755 /etc/zabbix/externalscripts/monitor-slave-status.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/monitor-slave-status.sh
chmod 755 /etc/zabbix/externalscripts/monitor-mysql-alive.sh
chown zabbix:zabbix /etc/zabbix/externalscripts/monitor-mysql-alive.sh
chown -R zabbix:zabbix /etc/zabbix/externalscripts/monitor-mha.sh
chmod 755 /etc/zabbix/externalscripts/monitor-mha.sh
cat >/etc/zabbix/externalscripts/disk.sh <<EOF
#!/bin/bash
diskarray=(\`cat /proc/diskstats |grep -E "\bvd[abcdefg]\b|\bsd[abcdefg]\b|\bc0d0p[0-9]\b"|grep -i "\b\$1\b"|awk '{print \$3}'|sort|uniq   2>/dev/null\`)
length=\${#diskarray[@]}
printf "{\n"
printf  '\t'"\"data\":["
for ((i=0;i<\$length;i++))
do
    printf '\n\t\t{'
    printf "\"{#DISK}\":\"\${diskarray[\$i]}\"}"
    if [ \$i -lt \$[\$length-1] ];then
            printf ','
    fi
done
printf  "\n\t]\n"
printf "}\n"
EOF
chown -R zabbix:zabbix /etc/zabbix/externalscripts/disk.sh
chmod 755 /etc/zabbix/externalscripts/disk.sh

################set iptables##############
iptable_num=`iptables-save |grep ${zabbix_proxy_server_ip}|wc -l`

if [ ${iptable_num} -ge 1 ];then
echo "iptables had been added!"
else
iptables -I INPUT 3 -s ${zabbix_proxy_server_ip}/32 -j ACCEPT
iptables-save >/etc/sysconfig/iptables
fi
echo "Congratulations on your successful installation!"
service zabbix-agent restart

}

function uninstall_zabbix_agent() {

################uninstall zabbix##############
if [ $(id -u) != "0" ]; then
    echo -e "\033[1;31m Error: You must be root to run this script!\033[0m"
    exit 1
fi
system_version=$(uname -m)

if [[ $(grep -E -c "CentOS|Hat" /etc/redhat-release) = 1 ]];then
      rpm -e zabbix-agent
      rpm -e zabbix
else [[ $(grep -E -c "Ubuntu|Debian" /etc/issue) = 1 ]]
       dpkg -P zabbix-agent
fi
    
iptables -D INPUT -s ${zabbix_server_ip}/32 -j ACCEPT
     
if [ -f  /etc/init.d/zabbix_agent_om ];then
rm -rf /etc/init.d/zabbix_agent_om
else
echo "clear old zabbix_agent binary file over"
fi
      

if [ -f /etc/zabbix/externalscripts/disk.sh ];then
rm -rf /etc/zabbix/externalscripts/disk.sh
else
echo "clear disk discovery scirpts  over"
fi


}
case $1 in 
 install_agent) 
        modify_dash
        install_zabbix_agent
            ;;
 install_proxy_agent)
        modify_dash
        install_zabbix_proxy_agent
		    ;;

 uninstall) 
        uninstall_zabbix_agent
            ;;			
  *) 
        echo "                                                    "
		echo "Usage:$0(install_agent|install_proxy_agent|uninstall)" 
		echo "NAME"
		echo "          used to install zabbix agent"
		echo "DESCRIPTION"
		echo "           install_agent:install zabbix agent"
		echo "           install_proxy_agent:install zabbix proxy agent"
		echo "           uninstall:unintall agent"
        ;; 
esac 
