#!/bin/bash

ipaddr_gzqxg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "121.14."|wc -l`
ipaddr_gzqxg_jx2_proxy='121.14.30.85'

ipaddr_tjyxb=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "42.62."|wc -l`
ipaddr_bjlg_proxy='42.62.96.96'

function install_agent() {

  wget http://42.62.120.210:10086/jx2/zabbix-2.2.4-jx2.sh
  /bin/bash zabbix-2.2.4-jx2.sh uninstall $1 
  /bin/bash zabbix-2.2.4-jx2.sh install_proxy_agent  $1
  rm -rf zabbix-2.2.4-jx2.sh


}

if [ ${ipaddr_gzqxg} -ge 1 ];then

    install_agent ${ipaddr_gzqxg_jx2_proxy}

else
   
    install_agent ${ipaddr_bjlg_proxy}

fi
