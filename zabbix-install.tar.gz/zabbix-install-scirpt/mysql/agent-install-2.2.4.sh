#!/bin/bash
#author qunxue
#version 0.1
#update logs:
#1.add argv for scripts at 2015/07/02
#ipaddr_bjlg=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "42.62.96|42.62.102|115.182.195|123.59.13.|10.136.62|10.136.63|42.62.95|115.183.195.3"|wc -l`


#pubip=`curl -s  http://120.92.16.56/get.php|awk -F[\"] '{print $4}'`
#pubip=`curl -s http://ipinfo.io|grep ip|awk -F[\"] '{print $4}'`
pubip=`curl -s http://ip.cn|awk '{print $2}'`
ipaddr_bjlg=`echo $pubip|grep -E "42.62.96|42.62.118|42.62.102|42.62.95|42.62.120|125.254.132.|121.78.69|123.207\.|123.206\."|wc -l`
ipaddr_bjlg_proxy='42.62.96.96'


ipaddr_txly=`ip a| grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"|grep -E "10.20.102|10.20.103"|wc -l`
ipaddr_txly_proxy='10.20.102.241'


ipaddr_bjzw=`echo $pubip|grep -E "42.62.70|42.62.15|211.155\.|42.62.10\.|115.182|58.229.185|124.115.21\."|wc -l`
ipaddr_bjzw_proxy='42.62.15.221'


ipaddr_gzqxg=`echo $pubip|grep -E "121.14.23|121.14.11|121.14.30|121.14.28|121.14.64|113.106\.|59.37\."|wc -l`
ipaddr_gzqxg_proxy='121.14.30.85'

ipaddr_tjyxb=`echo $pubip|grep -E "125.39.38\.|125.39.61\.|125.39.62\.|125.39.136"|wc -l`
ipaddr_tjyxb_proxy='125.39.62.192'

ipaddr_bjyz=`echo $pubip|grep -E "120.92.45\.|120.92.9\.|120.92.10\.|120.92.18\.|120.92.90\.|120.92.102.|120.132|120.131|123.59|120.92.56|120.92.3\.|120.92.19\.|120.92.15\.|120.92.89.|120.92.2\.|120.92.4\.|120.92.14\.|120.92.92\.|120.92.77\.|120.92.33\.|120.92.91.|120.92.36\.|120.92.45\.|120.92.86.|120.92.85.|120.92.42.|120.92.92\.|120.92.117\.|120.92.44\.|120.92.20.|120.92.94.|120.92.93.|123.207.159.|123.207.148.|139.199.121|139.199.27."|wc -l`
#ipaddr_bjyz_proxy='120.132.90.31'
ipaddr_bjyz_proxy='120.92.85.123'
#ipaddr_bjyz_proxy='10.254.9.178'

ipaddr_hk=`echo $pubip|grep -E "61.8\.|205.252|223.197|103.9.79\.|161.202.16\.|119.81\."|wc -l`
#ipaddr_hk_proxy='172.16.1.12'
ipaddr_hk_proxy='205.252.235.74'

ipaddr_tw=`echo $pubip|grep -E "203.66.80\.|202.170.113|203.12\.|203.162\.|203.66\.|211.20.181"|wc -l`
ipaddr_tw_proxy='205.252.235.74'

ipaddr_usa=`echo $pubip|grep -E "52.74\.|52.77\.|52.43\.|128.177.68\.|13.229\.|13.228\.|52.221\.|52.74\."|wc -l`
ipaddr_usa_proxy='52.1.88.210'

ipaddr_bjdx=`echo $pubip|grep -E "120.92.14\."|wc -l`
ipaddr_bjdx_proxy='172.24.150.34'


ipaddr_bjdx_pub=`echo $pubip|grep -E "120.92.10\.|120.92.52\."|wc -l`
ipaddr_bjdx_pub_proxy='120.92.14.34'

ipaddr_shqu=`echo $pubip|grep -E "101.251.|101.251|120.92.230|120.92.232|120.92.136|120.92.234|120.92.154\.|120.92.144|120.92.142|120.92.140|120.92.145\.|120.92.147\.|120.92.159\.|120.92.158\."|wc -l`
ipaddr_shqu_proxy='120.92.230.105'

ipaddr_shhb=`echo $pubip|grep -E "61.129.48|61.129.53|61.129.59|61.129.91|61.129.73|61.152.146|222.73.48|222.73.9\.|180.235."|wc -l`
ipaddr_shhb_proxy='180.235.73.131'


function install_agent()
{
 if [ ${ipaddr_hk} -ge 1 -o  ${ipaddr_usa} -ge 1 ];then
 
 wget http://205.252.235.74:10086/mysql/zabbix-2.2.4-base.sh
  /bin/bash zabbix-2.2.4-base.sh uninstall $1
  /bin/bash zabbix-2.2.4-base.sh install_proxy_agent  $1
  rm -rf zabbix-2.2.4-base.sh
  
 else
  wget http://42.62.120.210:10086/mysql/zabbix-2.2.4-base.sh
  /bin/bash zabbix-2.2.4-base.sh uninstall $1
  /bin/bash zabbix-2.2.4-base.sh install_proxy_agent  $1
  rm -rf zabbix-2.2.4-base.sh
  fi
}

if [ ${ipaddr_bjlg} -ge 1 ];then

     install_agent ${ipaddr_bjlg_proxy}

elif [ ${ipaddr_txly} -ge 1  ];then
     install_agent ${ipaddr_txly_proxy}

elif [ ${ipaddr_shhb} -ge 1   ];then
     install_agent ${ipaddr_shhb_proxy}

elif [ ${ipaddr_bjzw} -ge 1 ];then
  
     install_agent ${ipaddr_bjzw_proxy}  

elif [ ${ipaddr_tw} -ge 1 ];then
  
     install_agent ${ipaddr_tw_proxy} 

elif [ ${ipaddr_gzqxg} -ge 1 ];then
    
     install_agent ${ipaddr_gzqxg_proxy}

elif [ ${ipaddr_hk} -ge 1 ];then
   
     install_agent ${ipaddr_hk_proxy}

elif [ ${ipaddr_usa} -ge 1 ];then
    
     install_agent ${ipaddr_usa_proxy}

elif [ ${ipaddr_tjyxb} -ge 1 ];then
    
     install_agent ${ipaddr_tjyxb_proxy}

elif [ ${ipaddr_bjyz} -ge 1 ];then
   
     install_agent ${ipaddr_bjyz_proxy}

elif [ ${ipaddr_bjdx} -ge 1  ];then 
    install_agent ${ipaddr_bjdx_proxy}

elif [ ${ipaddr_bjdx_pub} -ge 1   ];then 
    install_agent ${ipaddr_bjdx_pub_proxy} 
	
elif [ ${ipaddr_shqu} -ge 1   ];then
    install_agent ${ipaddr_shqu_proxy}

#elif [ ${ipaddr_bjplatform} -ge 1   ];then
#    install_agent ${ipaddr_bjplatform_proxy}
fi
